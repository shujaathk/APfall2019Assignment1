#include <fstream>
#include <stdio.h>
#include <string.h>
#include<iostream>
using namespace std;

struct word {
    char val[50];
    int counter;
    bool del = false;
};

int n = 0;

bool ifdupli(char firstWord[50], char nextword[50], int size);

int main()
{
    
    ifstream infile("File.txt");
    char charc;
    int size = 0;
    // if no file exit
    if (!infile.is_open()) {
        cout<<"file name\"File.txt\" is not exist.";
        exit(0);
    }
    // count alphabets in file and then create a dynamic array
    while(infile.get(charc)){
        size++;
    }
    infile.close();
    
    infile.open("File.txt");
    //dynamic array
    char *phrase = new char[size-1];
    int i = 0;
    //redading one by one file
    while(infile.get(charc)){
        
        phrase[i] = charc;
        i++;
    }
    infile.close();
    
    
#pragma region Separate words and count of words and store it in structure array
    char* alphabet = strtok(phrase, " ");
    
    word detailword[300];
    word onealphabet;
    int totalwords = 0;
    
    char* secondword;
    int countsecondword = 0;
    while (alphabet != NULL)
    {
        secondword = alphabet;
        countsecondword = 0;
        while (secondword != NULL)
        {
            if (*secondword == '\0')
                break;
            onealphabet.val[countsecondword] = *secondword;
            secondword = secondword + 1;
            countsecondword++;
        }
        onealphabet.counter = countsecondword;
        detailword[totalwords] = onealphabet;
        alphabet = strtok(0, " ");
        totalwords++;
    }
    
#pragma endregion
    
    
#pragma region Remove duplicates
    for (int i = 0; i < totalwords; i++)
    {
        for (int j = i + 1; j < totalwords; j++)
        {
            if (detailword[i].counter == detailword[j].counter) {
                if (ifdupli(detailword[i].val, detailword[j].val, detailword[i].counter)) {
                    detailword[j].del = true;
                    continue;
                }
            }
        }
        
    }

    
    
//sort with word count
    word temporary;
    for (int i = totalwords - 1; i >= 0; i--)
    {
        for (int x = 0; x < totalwords; x++)
        {
            if (detailword[x].del)
                continue;
            
            if (detailword[x].counter > detailword[x + 1].counter)
            {
                temporary = detailword[x + 1];
                detailword[x + 1] = detailword[x];
                detailword[x] = temporary;
            }
        }
    }
#pragma endregion
    
    
#pragma region Output top letters
    
    char singleletter;
    int totalCount = 1;
    for (int i = totalwords; i >= 0; i--)
    {
        if (detailword[i].del)
            continue;
        
        if (detailword[i].counter < 0)
            continue;
        
        printf("Word no %d: ", totalCount);
        for (int j = 0; j < detailword[i].counter; j++)
        {
            singleletter = detailword[i].val[j];
            //printf("" + letter);
            printf("%c", singleletter);
        }
        printf("\t, Number of characters: %d", detailword[i].counter);
        printf("\n");
        
        if (totalCount == 10)
            break;
        
        totalCount++;
    }
    printf("press any key to stop");
    getchar();
    
#pragma endregion
    
    
    return 0;
}


bool ifdupli(char firstWord[50], char secondWord[50], int size) {
    bool duplicate = false;
    for (int i = 0; i < size; i++)
    {
        if (firstWord[i] != secondWord[i])
            break;
        
        duplicate = true;
    }
    
    return duplicate;
}
