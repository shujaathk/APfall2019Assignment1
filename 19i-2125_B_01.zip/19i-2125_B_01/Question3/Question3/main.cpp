#include <iostream>

using namespace std;





class Node  //class of type node with pointer declared and data

{
    
public:
    
    int data;
    
    Node *next;
    
};

Node *start=NULL; //head is declared globally





void swap(int x, int y )  //swap 2 integer

{
    
    
    
    if (x == y) //if x and y are equal
        
    {
        
        cout<<"x = y";
        
        return;
        
        
        
    }
    
    
    
    
    
    Node *prevcurr = NULL;//Apointer having adress of prev to curr 1st node
    
    Node *curr = start;  //curr node is euql to start
    
    while (curr && curr->data != x)  //until data not-found
        
    {
        
        prevcurr = curr;
        
        curr = curr->next;
        
    }
    
    
    
    
    
    Node *prevcurrb = NULL;//pointer with address  node prev to cur for 2nd Node find to be swaped
    
    Node *currb = start;  //declar curr node and equla to start
    
    while (currb && currb->data != y)   //until data not found
        
    {
        
        prevcurrb = currb;
        
        currb= currb->next;
        
    }
    
    
    
    
    
    if (curr == NULL ||currb == NULL) // if node not in list do nothing
        
    {
        
        cout<<"x or y is not in the list";
        
        return;
        
        
        
    }
    
    
    
    
    
    
    
    
    
    if (prevcurr!= NULL) //start not head
        
        prevcurr->next = currb;
    
    else
        
        start = currb;  //make next to start as head
    
    
    
    
    
    if (prevcurrb != NULL)  //2nd is not head
        
        prevcurrb->next = curr;
    
    else // make x new head
        
        start = curr;  //make 2nd as head
    
    
    
    //swap pointer
    
    Node *temporry = currb->next;
    
    currb->next = curr->next;
    
    curr->next = temporry;
    
}





void insertion(int new_data)  //insertion

{
    
    
    
    Node* new_node =new Node(); //making node
    
    
    
    
    
    new_node->data = new_data; //Put data
    
    
    
    
    
    new_node->next = start;  //link prev node with new one
    
    
    
    
    
    start = new_node;  //new as head
    
}





void Display()  //display func

{
    
    Node *cur1 = start;
    
    while( cur1!= NULL)
        
    {
        
        cout<<cur1->data<<" ";
        
        cur1 = cur1->next;
        
    }
    
}





int main()

{
    
    
    
    //Iinsert
    
    insertion(7);
    
    insertion(6);
    
    insertion(5);
    
    insertion(4);
    
    insertion(3);
    
    insertion(2);
    
    insertion(1);
    
    
    
    //swap 1 and 4
    
    Display();  //disply before swap
    
    
    
    swap(1, 4);  //swap
    
    cout<<endl;
    
    
    
    Display();  //after swap
    
    
    
    return 0;
    
}



