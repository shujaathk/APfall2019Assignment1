#include <iostream>
#include <fstream>

using namespace std;
char *Uppercase = "ZYXWVUTSRQPONMLKJIHGFEDCBA";
char *Lowercase = "zyxwvutsrqponmlkjihgfedcba";
//Convertion function
char encryptanddecrypt(char Character)
{
    
    int j;
    //Capital letters.
    if(int(Character) >= 65 && int(Character) <= 90)
    {
        j =  int(Character) - 65;
        return Uppercase[j];
        //small letters.
    }
    else if(int(Character) >= 97 && int(Character) <= 122)
    {
        j = int(Character) - 97;
        return Lowercase[j];
    }
}

int main()
{
    // creates file
    ifstream in("basic.txt");
    char character;
    
    ofstream out("output.txt", ios::trunc);
    //Read "basic.txt" file alphabet by alphabet
    cout<<"Encrypted input file \"basic.txt\". and \" Encryption.txt\".\n\n";
    while(in.get(character)){
        
        if((int(character) >= 65 && int(character) <= 90) || (int(character) >= 97 && int(character) <= 122))
        {
            out<<encryptanddecrypt(character);
            cout<<encryptanddecrypt(character);
        }
        else{
            out<<character;
            cout<<character;
        }
    }
    in.close();
    out.close();
    cout<<"\n\n";
    //Decryption
    //Encryption.txt  for decryption
    in.open("Encryption.txt");
    //Read "Encryption.txt" character by character.
    cout<<"after decryption of basic file \"Encryption.txt\".\n\n";
    while(in.get(character)){
        
        if((int(character) >= 65 && int(character) <= 90) || (int(character) >= 97 && int(character) <= 122))
        {
            //call function
            cout<<encryptanddecrypt(character);
        }
        else
        {
            //output character
            cout<<character;
        }
    }
    in.close();
    
    return 0;
}
