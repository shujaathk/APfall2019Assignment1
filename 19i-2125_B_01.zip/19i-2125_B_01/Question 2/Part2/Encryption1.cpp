#include <iostream>
#include <fstream>

using namespace std;

//encrypt alphabet and  its ascii value ,mod/ 23.
const int rem = 23;
const int num = 10;
int encrypt(char c){


		//for capital alphabets.
	if(int(c) >= 65 && int(c) <= 87){
		return  (int(c) % rem);

	}else if(int(c) >= 88 && int(c) <= 90){
		//for X< y and Z as they have same as A , B and C
		return ((int(c) % rem) +num);
	}
}

char decryption(int x){

		//Reads 2 consectives
			//hadeling repeating raminder and quotients
		if(x >= 19 && x <= 22){
			x = (rem * 2 ) + x;
			return char(x);
		}else if(x >= 0 && x <= 18){
			x = (rem * 3 ) + x;
			return char(x);
		}else if(x >= 29 && x <= 31){
			x = (rem * 3 ) + (x-num);
			return char(x);
		}
}

int main(){
	//Encryption
	// Open File.txt file
	ifstream in("Basic.txt");
	int i = 0;
	char c;
	ofstream out("Encrypted.txt", ios::trunc);
		//Read "File.txt" character by character 
	while(in.get(c)){

		// write encryption code in en.txt file. every rem is seprated by comma space " ".
		if(int(c) >= 65 && int(c) <= 90){
			out<<encrypt(c);
			out<<' ';
			i++;
		}else{
			// every other character will be put as it.
				out<<c;
				out<<' ';
				i++;
		}
		i++;
	}
	in.close();
	out.close();

    //decryption
	//Encrypted.txt will be input
	in.open("Encrypted.txt");
	int x;
	//Reads "Encrypted.txt" until detects , .
	while(in>>x){
		
		if((x >= 0 && x <= 22) || (x >= 26 && x <= 31 )){
			cout<<decryption(x);
		}
	}
	in.close();
	
	return 0;
}
