#include <iostream>

using namespace std;

struct Node1 //Creates a node
{
    int data; //first data
    Node1 *next; // the pointer
};

struct Node1 *start=NULL; //Head declared . Globally

void disfunc() //Display Function
{
    struct Node1 *curr;
    curr=start;
    while(curr!=NULL){
        
        cout<<curr->data<<"\t";
        curr=curr->next;
    }
    
}


void insertdata(int x)//Insertion function and then sort the node
{
    
    struct Node1 *curr;
    struct Node1 *prevcurrent=NULL;
    curr = start;
    if(start==NULL || x <= start->data)// node at the start of data is less
    {
        
        Node1 * tempnode=new Node1;
        tempnode->data=x;
        tempnode->next=start;
        start=tempnode;
    }
    else{
        
        while(curr->next!=NULL &&   curr->next->data < x)//Insert at the middle in sorted form.
        {
            prevcurrent=curr;
            curr=curr->next;
        }
        
        Node1 * temporarynode=new Node1;
        temporarynode->data=x;
        temporarynode->next = curr->next    ;
        curr->next =temporarynode;
    }
}

void deletenode(int x)//delete a note in a sorted list
{
    struct Node1 *curr = start;
    struct Node1 *prevcurr=NULL;
    while(curr && curr->data !=x)//traverse till required data not found
    {
        prevcurr = curr;
        curr =curr->next;
        
    }
    if(curr)//curr not nul
        if(prevcurr)//prevcurr not null or del at the head
        {
            prevcurr->next = curr->next;
            delete curr;
            
        }else{
            start = curr->next; //head note deletion
            delete curr;
            
        }
}

int main()//Main function
{
    insertdata(12);
    insertdata(10);    
    insertdata(14);
    deletenode(12);
    
    disfunc();
    return 0;
    
}
