#include <iostream>
#include <fstream>

using namespace std;
//Declare a list that will have less than 11 nodes. This will stroe largest 10 unique words along with their length and occurence
struct Node{
	char *word;
	int length;
    int count;
    Node *next;
};
 
//Declare a starting node (head).
struct Node *head = NULL;
//This function will return the length of a word.
int lengthOfCharacters(char *word){
	int i = 0;
    while( word[i] != '\0' ){
    	i++;
	}
    return i;
}
//This function will receive two words and compare. If these are equal it will return TRUE otherwise FALSE.
bool compare(char *word1, char* word2){
	int i = 0;
	while(word1[i] != '\0'){
		if(word1[i] != word2[i]){
			return false;
		}
		i++;
	}
	return true;
}
//This function will receive a char typed pointer array and a word. if the word is exist in pointer array it will return TRUE else FALSE.
bool exist(char* pointerArray[], char* word) {
	int i = 0;
    while(pointerArray[i] != '\0')
    {
  //  	cout<<pointerArray[i]<<" ";
  		//Call compare function to compare two words. If we compare directly (pointerArray[i] == word) it will copmare the addresses.
        if (compare(pointerArray[i], word))
        {
            return true;
        }
        i++;
    }
    return false;
}
//This function count the the total Nodes and return the number of total nodes.
int countNode(){
    struct Node *currentNode = head;
    int i = 0;
    while(currentNode != NULL){
    	currentNode = currentNode -> next;
		i++;
    }
    return i;
}
//This function will delete the last node of the list.
void deleteNode(){
	//If list is not exist.
	if(head == NULL){
    	return;
	}else{
		//Delete a last node.
		struct Node *currentNode = head;
		struct Node *previousNode = head;
		while(currentNode -> next != NULL){
			previousNode = currentNode;
			currentNode = currentNode -> next;
		}
		previousNode -> next = currentNode -> next;
		delete(currentNode);
		return;
	}
}
//This function will receive a word along with its length and occurence. This function compare the lenth of word with existing words.
//If the length is greater than first Node -> length then insert it in the start.
//If the length of coming word is less then existing words then it will move next node.
//This function will keep largest word at start and so on.
void listOfTop10(int ln, int c, char *W ){
	//Create a list if list not exist. If list exist then creat a new node at start of the the list.
	if(head == NULL || ln >= head -> length){
		
    	struct Node *newNode = new Node;
    	newNode -> count = c;
    	newNode -> length = ln;
    	newNode -> word = W ;
    	newNode -> next = head;
    	head = newNode;
	}else{
		//Create a new node at middle or end.
		Node *currentNode = head;
		//This will find the location of new Node.
		while(currentNode -> next != NULL && ln < currentNode -> next -> length ){
			
			currentNode = currentNode -> next;
		}
		struct Node *newNode = new Node;
		newNode -> count = c;
    	newNode -> length = ln;
    	newNode -> word = W ;
		newNode -> next = currentNode -> next;
		currentNode -> next = newNode;
	}
	//This condition will true when the number of nodes greater than 10.
	//This is for only 10 words should be stored.
	if(countNode() > 10){
		//This function will delete the last node. 
		deleteNode();
	}
}
//This function display the all nodes the list.
void display(){
    if(head == NULL){
        cout<<"List is empty!"<<endl;
        return;
    }
    struct Node *currentNode = head;
    while(currentNode != NULL){

        cout<<currentNode -> word<<"\t"<<currentNode -> count <<"\t"<<currentNode -> length<<endl;
        currentNode = currentNode -> next;
    }
    cout<<endl;
}

int main(){
	// Open an input file named File.txt
	ifstream inputFile("File.txt");
    int sizeOfData = 0;
    char *words = new char;
    //If file does not exist
    if (!inputFile.is_open()) {
		cout<<"The file named \"File.txt\" is not exist.";
		exit(0);
	}
	//This will count the words in the file.
    while(inputFile>>words)
    {
        sizeOfData++;
    }
    inputFile.close();
    //Creat the dynamic array of size sizeOfWord.
    char** pointerCharString = new char*[sizeOfData];
    pointerCharString[sizeOfData] = NULL;
    int i = 0;
    //Read the file word by word and stored in the pointerCharString.
    inputFile.open("File.txt");
    while(inputFile>>words)
    {
        pointerCharString[i] = words;
        words = new char;
        i++;
    }
    //This is dynamic array for unique words.
    char** pointerUniqueWords = new char*[sizeOfData];
    //This is dynamic array for occureces of words.
    int* pointerWordOccurence = new int[sizeOfData];
    int x = 0;
    //This will find the unique words and their occurences.
    for(i = 0; i < sizeOfData; i++){
		if(!exist(pointerUniqueWords, pointerCharString[i])){
			pointerWordOccurence[x] = 0;
			pointerUniqueWords[x] = pointerCharString[i];
			
    		for(int j = i; j < sizeOfData; j++){
    			if(compare(pointerCharString[i], pointerCharString[j])){
    				pointerWordOccurence[x]++;
				}
			}
			x++;
		}
	}
	i = 0;
	//To avoid the garbage value,
	pointerUniqueWords[x] = '\0';
	//This will save the largest unique words along with their occurences and length in list.
	while(pointerUniqueWords[i] != '\0'){
		listOfTop10(lengthOfCharacters(pointerUniqueWords[i]), pointerWordOccurence[i], pointerUniqueWords[i] );
		i++;
	}
	
    cout<<"\n\n";
    display();
	return 0;
}
