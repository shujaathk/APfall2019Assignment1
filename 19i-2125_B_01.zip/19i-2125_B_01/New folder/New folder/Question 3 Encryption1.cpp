#include <iostream>
#include <fstream>

using namespace std;

//This function will converts letter to another letter. A to Z, Y to B, X to C and so on. (Vise Versa)
char* encryption1(char *pointerOfCharArray){
	int i = 0, j;
	
	while(pointerOfCharArray[i]){
		//For Capital letters.
		if(int(pointerOfCharArray[i]) >= 65 && int(pointerOfCharArray[i]) <= 90){
			j =  ( 90 - int(pointerOfCharArray[i]) ) + 65;
			pointerOfCharArray[i] = char(j);
			//For small letters.
		}else if(int(pointerOfCharArray[i]) >= 97 && int(pointerOfCharArray[i]) <= 122){
			j =  ( 122 - int(pointerOfCharArray[i]) ) + 97;
			pointerOfCharArray[i] = char(j);
		}
		//All other characters will be the same.
		i++;
	}
	return pointerOfCharArray;
}

int main(){
	//////////////////////////////////////==================  Encryption Part  =============//////////////////////////////////
	// Open an input file named File.txt
	ifstream inputFile("File.txt");
	char character;
	int sizeOfData = 0;
	// Program will check if file does not open then exit program.
	if (!inputFile.is_open()) {
		cout<<"The file named \"File.txt\" is not exist.";
		exit(0);
	}
	// Count the size of characters in "File.txt" file to create a dynamic Character array.
	while(inputFile.get(character)){

		sizeOfData++;
	}
	inputFile.close();
	//Create a dynamic character array.
	char *pointerCharString = new char[sizeOfData-1];
	int i = 0;
	inputFile.open("File.txt");
	
	//Read "File.txt" character by character and stored in a Character array referenced by pointer "pointerCharString".
	while(inputFile.get(character)){

		pointerCharString[i] = character;
		i++;
	}
	inputFile.close();
	//Replace delemeter to end of array.
	pointerCharString[i] = '\0';
	//Encrypt the character array and stored in a pointer "pointerCharString".
	pointerCharString = encryption1(pointerCharString);
	cout<<endl<<endl;
	cout<<pointerCharString<<"\n\n";
	
	//Write the encrypted form of input file "File.txt" in "Encryption1.txt" file.
    ofstream outputFile("En1.txt", ios::trunc);
    outputFile << pointerCharString;
    outputFile.close();
    //////////////////////////////////////==================  Decryption Part  =============//////////////////////////////////
	//Encryption1.txt file is the input file for decryption.
	inputFile.open("En1.txt");
	sizeOfData = 0;
	// Program will check if file does not open then exit program.
	if (!inputFile.is_open()) {
		cout<<"The file named \"En1.txt\" is not exist.";
		exit(0);
	}
	// Count the size of characters in file "Encryption1.txt" to create a dynamic
	while(inputFile.get(character)){

		sizeOfData++;
	}
	inputFile.close();
	// Delete previous array.
	delete(pointerCharString);
	pointerCharString = new char[sizeOfData-1];
	i = 0;
	inputFile.open("En1.txt");
	//Read "Encryption1.txt" character by character and stored in a Character array referenced by pointer "pointerCharString".
	while(inputFile.get(character)){

		pointerCharString[i] = character;
		i++;
	}
	inputFile.close();
	//Replace delemeter to end of array.
	pointerCharString[i] = '\0';
	//Encrypt the character array and stored in a pointer "pointerCharString".
	pointerCharString = encryption1(pointerCharString);
	cout<<endl<<endl;
	//Show the decrypted form of input file "Encryption1.txt" file.
	cout<<pointerCharString<<"\n";
	
	return 0;
}
