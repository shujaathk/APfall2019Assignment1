#include <iostream>
 
using namespace std;
 
//Declare a Node.
struct Node{
    int data;
    Node *next;
};
 
//Declare a starting node (head).
struct Node *head = NULL;
 
//Insert a node in a sorted list.
void insertNode(int n){
	//Create a list if list not exist. If list exist then creat a new node at start of the the list.
	if(head == NULL || n <= head -> data){
		
    	struct Node *newNode = new Node;
    	newNode -> data = n;
    	newNode -> next = head;
    	head = newNode;
	}else{
		//Create a new node at middle or end.
		Node *currentNode = head;
		while(currentNode -> next != NULL && n > currentNode -> next -> data ){
			
			currentNode = currentNode -> next;
		}
		struct Node *newNode = new Node;
		newNode -> data = n;
		newNode -> next = currentNode -> next;
		currentNode -> next = newNode;
	}
}

//Display all nodes.
void display(){
    if(head == NULL){
        cout<<"List is empty!"<<endl;
        return;
    }
    struct Node *currentNode = head;
    while(currentNode != NULL){

        cout<<currentNode -> data <<" ";
        currentNode = currentNode -> next;
    }
    cout<<endl;
}
 
//Find a node in the list and delete it from a sorted list.
void deleteNode(int n){
	//If list is not exist.
	if(head == NULL){
    	cout<<"Sorry list is empty.\n";
    	return;
	}else{
		//Delete a first node (a special case)
		if(n == head -> data){
			struct Node *tempNode = head;
			head = head -> next;
			delete(tempNode);
			return;
		}
		Node *currentNode = head;
		while(currentNode -> next != NULL){
			//Delete a node from middle or end
			if( n == currentNode -> next -> data ){
				struct Node *tempNode = currentNode -> next;
				currentNode -> next = tempNode -> next;
				delete(tempNode);
				return;
			}
			currentNode = currentNode -> next;
		}
		cout<<"Sorr! Value is not found in the list.\n";
	}
}
int main(){
	
    display();
    insertNode(20);
    insertNode(5);
    insertNode(4);
    insertNode(7);
    insertNode(7);
    insertNode(80);
    insertNode(-3); 		// -3 is inserted at the start of the list
    display();
    deleteNode(80);
    display();
    return 0;
}

