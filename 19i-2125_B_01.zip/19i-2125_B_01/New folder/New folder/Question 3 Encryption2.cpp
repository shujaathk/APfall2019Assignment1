#include <iostream>
#include <fstream>

using namespace std;

//This function will encrypt the letter through its ascii value mod by 23.
//For example, if letter A�s ascii is 65, then 65%23 is 19. For letter A, 19 will be stored

void encryption2(char *pointerOfCharArray){
	int i = 0, j;
	char c;
	ofstream outputFile("En2.txt", ios::trunc);
	// Program will check if file does not open then exit program.
	if (!outputFile.is_open()) {
		cout<<"Opening the file named \"En2.txt\" error.";
		exit(0);
	}
	while(pointerOfCharArray[i]){
		//For Capital letters.
		if(int(pointerOfCharArray[i]) >= 65 && int(pointerOfCharArray[i]) <= 87){
			j =  int(pointerOfCharArray[i]) % 23;
			//For storing digits as character.
			if(j >= 10 && j <= 22){
				outputFile.put( (j/10) + '0');
				outputFile.put( (j%10) + '0');
			}else{
				//For storing minimum 2 digits of remainder. For example if remainder is 2 it will be stored as 02.
				outputFile.put('0');
				outputFile.put(j + '0');
			}
			
		}else if(int(pointerOfCharArray[i]) >= 88 && int(pointerOfCharArray[i]) <= 90){
			//This will hendel the case of X,Y and Z having same remainder with A,B and C. The number 5 will be added of their remainder.
			j =  (int(pointerOfCharArray[i]) % 23) +5;
			outputFile.put((j/10) + '0');
			outputFile.put((j%10) + '0');
			//Space will be as it.
		}else if(int(pointerOfCharArray[i]) == 32){
			outputFile.put(' ');
		}else{
			//Any other characters will be placed after equal operator "=" to defferentiate with remainders.
			outputFile.put('=');
			outputFile.put(pointerOfCharArray[i]);
 			//outputFile.put(')');
		}
		i++;
	}
	outputFile.close();
	cout<<endl<<endl;
}

void decryption2(char *pointerOfCharArray){
	cout<<endl<<endl;
	int i = 0, j;
	while(pointerOfCharArray[i]){
		//Read two consective digits
		if(isdigit(pointerOfCharArray[i]) && isdigit(pointerOfCharArray[i+1])){
			//Convert two consective digits into a single value. Like 1 and 9 will become 19.
			j =  (( pointerOfCharArray[i] - '0' )* 10) + (pointerOfCharArray[i+1] - '0');
			//These are the three cases to hendle the repeating remainder and the qoutient of different alphabets.
			if(j >= 19 && j <= 22){
				cout<<char(46+j);
				i += 2;
			}else if(j >= 0 && j <= 18){
				cout<<char(69+j);
				i += 2;
			}else if(j >= 24 && j <= 26){
				cout<<char(64+j);
				i += 2;
			}
			//If equaloperator occurs then simple print next character and move next.
		}else if(pointerOfCharArray[i] == '='){
			cout<<pointerOfCharArray[i+1];
			i += 2;
			//This is for new line and spaces.
		}else{
			cout<<pointerOfCharArray[i];
			i++;
		}
	}
	cout<<endl;
}

int main(){
	//////////////////////////////////////==================  Encryption Part  =============//////////////////////////////////
	// Open an input file named File.txt
	ifstream inputFile("File.txt");
	char character;
	int sizeOfData = 0;
	// Program will check if file does not open then exit program.
	if (!inputFile.is_open()) {
		cout<<"The file named \"File.txt\" is not exist.";
		exit(0);
	}
	// Count the size of characters in "File.txt" file to create a dynamic Character array.
	while(inputFile.get(character)){
		sizeOfData++;
	}
	inputFile.close();
	
	inputFile.open("File.txt");
	//Create a dynamic character array.
	char *pointerCharString = new char[sizeOfData-1];
	int i = 0;
	//Read "File.txt" character by character and stored in a Character array referenced by pointer "pointerCharString".
	while(inputFile.get(character)){

		pointerCharString[i] = character;
		i++;
	}
	inputFile.close();
	//Replace delemeter to end of array.
	pointerCharString[i] = '\0';
	//Encrypt the pointerCharString.
	encryption2(pointerCharString);

    //////////////////////////////////////==================  Decryption Part  =============//////////////////////////////////
	//Encryption2.txt file is the input file for decryption.
	inputFile.open("En2.txt");
	sizeOfData = 0;
	// Program will check if file does not open then exit program.
	if (!inputFile.is_open()) {
		cout<<"The file named \"En2.txt\" is not exist.";
		exit(0);
	}
	// Count the size of characters in file "Encryption2.txt" to create a dynamic
	while(inputFile.get(character)){
		sizeOfData++;
	}
	inputFile.close();
	// Delete previous array.
	delete(pointerCharString);
	//Create a dynamic character array.
	pointerCharString = new char[sizeOfData-1];
	i = 0;
	inputFile.open("En2.txt");
	//Read "Encryption2.txt" file character by character and stored in a Character array referenced by pointer "pointerCharString".
	while(inputFile.get(character)){

		pointerCharString[i] = character;
		i++;
	}
	inputFile.close();
	//Replace delemeter to end of array.
	pointerCharString[i] = '\0';
	//dencrypt the character array pointerCharString.
	decryption2(pointerCharString);
	
	return 0;
}
