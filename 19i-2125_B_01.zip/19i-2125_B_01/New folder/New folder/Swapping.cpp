#include <iostream>
 
using namespace std;
 
//Declare a Node.
struct Node{
    int num;
    Node *next;
};
 
//Declare starting node head.
struct Node *head=NULL;
//Swap two values in link list
//If any value is repeated then the last value will be replaced. Like 10,2,7,40,7,5 will be 10,7,7,40,2,5
void swaping(int value1, int value2){
 	if(head == NULL){
 		cout<<"There is no list exist.\n";
 		return;
	 }
	 int temp;
	 Node *value1Position = NULL;
	 Node *value2Position = NULL;
	 Node *currentNode = head;
	 while(currentNode != NULL){
	 	if(currentNode -> num == value1){
	 		value1Position = currentNode;
		 }
		 else if(currentNode -> num == value2){
		 	value2Position = currentNode;
		 }
		 currentNode = currentNode -> next;
	 }
	 if(value1Position == NULL || value2Position == NULL){
	 	cout<<"Value not found.\n";
	 	return;
	 }
	 temp = value1Position -> num;
	 value1Position -> num = value2;
	 value2Position -> num = temp;
 }
//Insert node a ne node
void insertNode(int n){
	//Insert new node at start if link list not exist.
	if(head == NULL){
    	struct Node *newNode=new Node;
    	newNode->num=n;
    	newNode->next=NULL;
    	head=newNode;
	}else{
		//Insert new node at middle or end
		Node *crrN = head;
		while(crrN-> next != NULL){
			
			crrN = crrN -> next;
		}
		Node *newNode = new Node;
		newNode -> num = n;
		newNode -> next = crrN -> next;
		crrN -> next = newNode;
	}
}
 
//Traverse/ display all nodes (print items)
void display(){
    if(head==NULL){
        cout<<"List is empty!"<<endl;
        return;
    }
    struct Node *temp=head;
    while(temp!=NULL){

        cout<<temp->num<<" ";
        temp=temp->next;
    }
    cout<<endl;
}
 
int main(){

    insertNode(10);
    insertNode(2);
    insertNode(7);
    insertNode(40);
    insertNode(7);
    insertNode(5);

    display();
    swaping(7,2);
    display();
	return 0;
}

