#include <iostream>
using namespace std;

void encode(char *source);
void decode(char *source);

int main(int argc, char const *argv[])
{
    char *toEncode = "Some Random Strong ABC abc";
    char *toDecode = "Hlnv Izmwln Hgilmt ZYX zyx";
    cout << toEncode <<endl;
    encode(toEncode);
    cout<<endl;
    cout << toDecode <<endl;
    decode(toDecode);

    return 0;
}

// encodes input string
void encode(char *source) {
    if (!source){
        return;
    }
    
    for (char *temp = source; *temp != '\0'; temp++) {
        if (*temp == ' ') {
            // skip if white space
           cout<<*temp;
           continue;
        }
        
        char result;
         // formula to encode characters
        if (islower(*temp)) {
            int diff = 'a' - *temp;
            result = ('z' + diff);
        } else {
            int diff = 'A' - *temp;
            result = 'Z' + diff;
        }

        cout<<result;
    }

    cout<<endl;
}

// decodes input string
void decode(char *source) {
    if (!source){
        return;
    }
    
    for (char *temp = source; *temp != '\0'; temp++) {
        if (*temp == ' ') {
            // skip if white space
           cout<<*temp;
           continue;
        }
        
        char result;
        // formula to decode characters
        if (islower(*temp)) {
            int diff = 'z' - *temp;
            result = ('a' + diff);
        } else {
            int diff = 'Z' - *temp;
            result = 'A' + diff;
        }

        cout<<result;
    }

    cout<<endl;
}