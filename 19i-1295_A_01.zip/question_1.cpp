struct Word
{
    public:
    char *data;
    int length;
    int occurance;
};

