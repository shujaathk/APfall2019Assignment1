#include <iostream>
using namespace std;

class Node {  
    public:
    int data;  
    Node* next;  
};  

class List
{
private:
    Node *head;
public:
    List();
    ~List();

    void insertNode(int data);
    void deleteNode(int data);
    void swapValues(int d1, int d2);
    Node* findNode(int d1);
    void print();
};

int main(int argc, char const *argv[]){
    List *list = new List();

    // questions 4: insert in sorted order
    list->insertNode(4);
    list->insertNode(6);
    list->insertNode(3);
    list->insertNode(4);
    list->insertNode(2);
    list->insertNode(1);
    list->insertNode(8);
    list->insertNode(9);
    list->insertNode(7);
    list->insertNode(5);
    list->print();

    cout<<endl;
    // questions 4: will delete all occurances of the given value
    list->deleteNode(4);
    list->print();

    cout<<endl;

    // question 3: swap values
    list->swapValues(3,8);
    list->print();

    return 0;
}

void List::swapValues(int d1, int d2) {
    Node *node1 = findNode(3);
    Node *node2 = findNode(8);

    if (node1 != NULL && node2 != NULL){
        int temp = node1->data;
        node1->data = node2->data;
        node2->data = temp;
    }
}

Node* List::findNode(int data) {
    Node *temp1 = head;
    Node *res = NULL;
    while (temp1 != NULL) {
        if (temp1-> data == data) {
            res = temp1;
            break;
        }  

        temp1 = temp1 -> next;
    }
    return res;
}

void List::insertNode(int data) {
    Node *node = new Node();
    node->data = data;
    node->next = NULL;

    if (head == NULL || head->data > node->data) {
        // i. if head is empty, make new node head
        // ii. if head's data is greater than new nodes' data then new node should be head, old head would become second node [if ASC sort order is requried]
        node -> next = head;
        head = node;
    } else {
        // locating node to insert
        Node *temp = head;
        while (temp->next != NULL && temp->next->data < node->data){ // keep on traversing until end or if next data is less than new node's data
            temp = temp -> next;
        }
        // need to insert new node after temp variable's node
        node->next = temp->next;
        temp->next = node;
    }
}

// this method will also handle multiple node delete if value matches
void List::deleteNode(int data) {
    Node *previous = NULL;
    Node *current = head;
    while (current->next != NULL){
        if (current->data == data) {
            // nodes value matches
            if (previous) {
                // not matched at head, somewhere down the list
                previous -> next = current -> next;
                delete current;
                current = previous -> next;   
            } else {
                // value matched at head
                head = current -> next;
                delete current;
                current = head;
            }
        } else {
            // value doesn't match, move forward
            previous = current;
            current = current -> next;
        } 
    }
}

void List::print() {
    Node *temp = head;  
    while(temp != NULL)  
    {  
        cout<<temp->data<<" ";  
        temp = temp->next;  
    } 
}

List::List(){
    head = NULL;
}

List::~List(){
    // list delete method copied from lecture slides
    Node* currNode = head;
    Node* nextNode = NULL;
    while (currNode != NULL){
        nextNode = currNode->next;
        delete currNode; // destroy the current node
        currNode = nextNode;
    }
}