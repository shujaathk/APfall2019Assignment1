// Q3_swap.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
using namespace std;

//  Node class of linked list
class Node {

public:
	int data;
	class Node* next;

	// constructor use to convert int to node
	Node(int value, Node* address): data(value), next(address)
	{
	}
	//to display the linked list
	void display_linkedList()
	{
		Node *z=this;
		while (z != NULL)
		{
			cout << z->data << " ";
			z = z->next;
		}
	}
	
};
Node **p = NULL;
Node  **q = NULL;
 //create nodes having data
void add_node(Node** head, int x)
{

	// node allocates
	(*head) = new Node(x, *head);
}
//if found both keys in linked list, swap them using pointers
void swapping(Node*& p, Node*& q)
{

	Node* tmp = p;
	p = q;
	q = tmp;
}
//match both keys and search them, found them and swap them
void find_swap(Node** head, int key1, int key2)
{
	
// if key1 and key2 
	if (key1 == key2)
		return;
// search for key1 and key2 in the linked list  and store therir pointer in p and q for swapping them easily
while (*head) {
	//match the key1 with value of head if found store it in p pointer 
		if ((*head)->data == key1) {
			
			p = head;
		}
	//match the key2 with value of head if found store it in q pointer
		else if ((*head)->data == key2) {
			
			q = head;
		}
	//if not found any of key at head place, traverse the next nodes to find a match
		head = &((*head)->next);
	}

	
//if both p & q are found
	if (p && q) {
		//swap the current pointers in the linked list
		swapping(*p, *q);
		//also swap the next pointer of the current ones
		swapping(((*p)->next), ((*q)->next));
	}
}
int main()
{

	Node* temp = NULL;
	//inserting the values to create nodes for linked list
	add_node(&temp, 9);
	add_node(&temp, 6);
	add_node(&temp, 5);
	add_node(&temp, 8);
	add_node(&temp, 3);
	add_node(&temp, 4);
	add_node(&temp, 7);
cout << "Before Swapping Linked list: "<<endl;
//to print the linked list this function is called
temp->display_linkedList();
//keys to be swapped 
find_swap(&temp, 7, 9);
cout << "\n After Swapping linked list:" <<endl ;
temp->display_linkedList();
	return 0;
	system("paused");
}
