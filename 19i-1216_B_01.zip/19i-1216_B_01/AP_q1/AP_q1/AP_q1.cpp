// AP_q1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include "pch.h"
#include<iostream>
#include <fstream>
#include <string>
using namespace std;

int main()
{
	int r = 100;
	int c = 30;

	char** arr1 = new char*[r];

	for (int i = 0; i < r; ++i)
	{
		arr1[i] = new char[c];
	}


	int count = 0;
	int i = 0;

	ifstream inFile;
	inFile.open("file1.txt");
	if (inFile.is_open())
	{
		while (!inFile.eof())
		{
			int j = 0;
			inFile.get(arr1[i][j]);
			while
				((arr1[i][j] != ' ') || (arr1[i][j] == '\n') || (arr1[i][j] == ',') || (arr1[i][j] == '.'))
			{

				j++;
				inFile.get(arr1[i][j]);
			}
			i++;
			count++;
		}
		inFile.close();
	}
	long temp[100];
	for (int i = 0; i < r; i++)
	{


		for (int j = 0; j < c; j++)
		{
			temp[i] = 0;
			if (arr1[i][j] <= 122 && arr1[i][j] >= 64)
			{
				temp[i] = temp[i] + tolower(arr1[i][j]) * (j + 1);
			}
																				  
		}

			
		
	}
	int pos[10];
	long top[10][2];
	for (int j = 0; j < 10; j++)
	{
		pos[j] = 0;
		top[j][0] = temp[0];
		for (int i = 0; i < r; i++)
		{
			if (top[j][0] < temp[i])
			{
				top[j][0] = temp[i];
				pos[j] = i;
			}
		}                
		top[j][1]=0;
		for (int i = 0; i < 100; i++)
		{
			if (top[j][0] == temp[i] && temp[i] != 0)
			{
				temp[i] = 0;
				top[j][1] = top[j][1] + 1;
			}
		}
		temp[pos[j]] = 0;
	}
	for (int i = 0; i < 10; i++)
	{
		for (int j = 0; j < 25; j++)
		{
			if (arr1[pos[i]][j] < 123 && arr1[pos[i]][j]>64)
			{
				cout << arr1[pos[i]][j];
			}
		}
		cout << " words occurences" << top[i][1] << endl;
	}
	
	
	return 0;
	system("PAUSE");

}