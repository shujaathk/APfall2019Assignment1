// AP_q2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <fstream>
#include <iostream>
using namespace std;
int main()
{
	int str_len =100;
	int i = 0;
	char* in_str;
	in_str = new char[str_len];
	cout << " encryption & decryption string :" << endl;
	cin.get(in_str, str_len);


	fstream en_file("en_file.txt", ios::out);
	char* en_str;
	en_str = new char[str_len];
	for (int i = 0; i < str_len; i++)
	{
		en_str[i] = in_str[i];

		if (en_str[i] > 64 && en_str[i] < 91)
			en_str[i] = 25 - (en_str[i] - 65) + 65;

		if (en_str[i] > 96 && en_str[i] < 123)
			en_str[i] = 25 - (en_str[i] - 97) + 97;
	}
	for (int i = 0; i < str_len; i++)
	{
		if ((en_str[i] > 64 && en_str[i] < 91) || (en_str[i] > 96 && en_str[i] < 123))
			en_file << en_str[i];
	}



	fstream de_file("de_file.txt", ios::out);
	char* de_str;
	de_str = new char[str_len];
	for (int i = 0; i < str_len; i++)
	{
		de_str[i] = en_str[i];
		if (de_str[i] > 64 && de_str[i] < 91)
			de_str[i] = 25 - (de_str[i] - 65) + 65;
		if (de_str[i] > 96 && de_str[i] < 123)
			de_str[i] = 25 - (de_str[i] - 97) + 97;
	}
	for (int i = 0; i < str_len; i++)
	{
		if ((de_str[i] > 64 && de_str[i] < 91) || (de_str[i] > 96 && de_str[i] < 123))
			de_file << de_str[i];
	}
	

	return 0;
		system("PAUSE");

	
}