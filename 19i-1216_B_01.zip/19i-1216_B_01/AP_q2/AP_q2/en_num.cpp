#include "pch.h"

/*#include <fstream>
#include <iostream>
using namespace std;
int main()
{
	char c;
	int res;
	string file= "num1_file.txt";
	ifstream is(file);
	ofstream outfile;
	outfile.open("num_file.txt");


		while (is.get(c))
		{

			res = int(c) % 23; 
			cout << res << "  ";
			outfile << res << " ";
		}
	
}
*/