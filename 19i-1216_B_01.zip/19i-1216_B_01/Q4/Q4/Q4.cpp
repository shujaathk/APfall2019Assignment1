// Q4.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
using namespace std;

class Node {

public:
	int data;
	class Node* next;

	// constructor use to convert int to node
	Node(int value, Node* address) : data(value), next(address)
	{
	}
	//to display the linked list
	void printList()
	{
		Node *z = this;
		while (z != NULL)
		{
			cout << z->data << " ";
			z = z->next;
		}
	}

};
//to create a linked list by taking values 
void add_node(Node** head, int x)
{

	// node allocates
	(*head) = new Node(x, *head);
}
//intialization of insert function at the beginning of sorted list
void in_begin(Node**head, int key);
//intialization of insert function at the end of sorted list
void in_end(Node**head, int key);

//function for insertion of elements in sorted order.
void in_sort(Node **head, int key) 
{    //if pointer head is NULL
	if (*head == NULL) 
	{    //head points to new created node having value in data part
		*head = (struct Node*) malloc(sizeof(struct Node));
		(*head)->data = key;
		(*head)->next = NULL;

	}
	else
	{   // if head is not null and there is any element in list
		//pointer temp will point head node
		struct Node* temp = *head;
		//until the next of node is not null it will keep executing 
		while (temp->next != NULL)
		{ //comparison of the key value with the data of next node
			if (key > temp->next->data) 
			{
				temp = temp->next;
			}
			else
			{   
				//if the key value is smaller than the value of already present node
				if (key < temp->data) 
				{
					//function of insertion at start will be called
					in_begin(head, key);
				}
				else
				{
					//traverse  through the nodes 
					struct Node* cNode = (struct Node*) malloc(sizeof(struct Node));
					cNode->data = key;
					cNode->next = temp->next;
					temp->next = cNode;
				}

				return;
			}
		}
		//if the key value is greater than the value of already present nodes
		if (key > temp->data) 
		{
			//function for insertion at end will be call
			in_end(head, key);
		}
	}
}
//function definition for insertion of node at the begining of  sorted linked list
void in_begin(Node**head, int key)
{
	struct Node* temp;
	temp = (struct Node*) malloc(sizeof(struct Node));
	temp->data = key;
	temp->next = (*head);
	(*head) = temp;
}
//function definition for insertion of node at the end of  sorted linked list
void in_end(Node**head, int key) 
{
	struct Node* temp;
	temp = (struct Node*) malloc(sizeof(struct Node));
	temp->data = key;
	struct  Node*current = *head;

//walk through the list until you reach the end of the list
	while (current->next != NULL)
	{
		current = (current)->next;
	}
//last element of list set as the new element
	(current)->next = temp;
//next of new node is set to NULL to denote the end odf list.
	temp->next = NULL;
}
//for the deletion of values from the linked list
void removeNode(Node** head,int key)
{
	//if the key value that need to be delete matched to the head node value
	//then function is set to delete the head node
if ((*head)->data == key) 
{
	 struct Node* temp = *head;
	 head = &((*head)->next);
		delete temp;

}
	else 
{
	//if the key value matches to another value of node from the list
	//the function will remove that node from the list
		struct Node* temp = *head;
		while (temp->next->data != key)
			temp = temp->next;

		struct Node* temp2 = temp->next;
		temp->next = temp2->next;
		free(temp2);

	}

}
int main()
{
	Node* head = NULL;

	//insertion of values in the list
	add_node(&head, 9);
	add_node(&head, 7);
	add_node(&head, 6);
	add_node(&head, 4);
	add_node(&head, 3);
	add_node(&head, 1);
	cout << "Given linked list: \n";
	//to print the linked list
	head->printList();
	in_sort(&head, 2);
	in_sort(&head, 5);
	cout << "\nInsertion in sorted linked list: \n";
	//to display the sorted linked list after insertion 
	head->printList();
	cout << "\n Deletion of an element from linked list: \n";
	removeNode(&head, 5);
	cout << endl;
	////to display the sorted linked list after deletion
    head->printList();
	system("pause");
	
	return (0);
}