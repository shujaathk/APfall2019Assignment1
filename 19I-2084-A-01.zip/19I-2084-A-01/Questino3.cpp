//#include <bits/stdc++.h> 
#include <cstddef>
#include <iostream>
using namespace std;

//Class for Linked list Data and address
class Node
{
public:
	int Data;
	Node* Next;
};


//Swaping the Nodes 
void swapNodes(Node** head_ref, int x, int y)
{
	//Check if x and y are same 
	if (x == y) return;

	// searching x
	Node* xprev = NULL, * xcurr = *head_ref;
	while (xcurr && xcurr->Data != x)
	{
		xprev = xcurr;
		xcurr = xcurr->Next;
	}

	// searching y
	Node* prevY = NULL, * ycurr = *head_ref;
	while (ycurr && ycurr->Data != y)
	{
		prevY = ycurr;
		ycurr = ycurr->Next;
	}

	// if both x and y not occures
	if (xcurr == NULL || ycurr == NULL)
		return;

	// checking if x is a head
	if (xprev != NULL)
		xprev->Next = ycurr;
	else 
		*head_ref = ycurr;

	// check if y is a head
	if (prevY != NULL)
		prevY->Next = xcurr;
	else 
		*head_ref = xcurr;

	// Swaping nodes
	Node* temp = ycurr->Next;
	ycurr->Next = xcurr->Next;
	xcurr->Next = temp;
}

/* Adding node at the start*/
void Insert(Node** head, int new_Data)
{
	/* new node */
	Node* NewNode = new Node();

	/* adding data */
	NewNode->Data = new_Data;

	/* linking the node */
	NewNode->Next = (*head);

	/* point head to the new node */
	(*head) = NewNode;
}

/*print values*/
void Print(Node* node)
{
	while (node != NULL)
	{
		cout << node->Data << " ";
		node = node->Next;
	}
}

/* Driver program to test above function */
int main()
{
	Node* start = NULL;

	/* Inserting data to linked list*/
	Insert(&start, 35);
	Insert(&start, 44);
	Insert(&start, 22);
	Insert(&start, 16);
	Insert(&start, 65);
	Insert(&start, 4);
	Insert(&start, 103);

	cout << "Before swaping ";
	Print(start);

	swapNodes(&start, 4, 3);

	cout << "\n After Swaping  ";
	Print(start);

	return 0;
}