//#include <bits/stdc++.h> 
#include <cstddef>
#include <yvals.h>
#include <iostream>
using namespace std;

/* structure of a linked list node */
class Node
{
public:
	int Data;
	Node* Next;
};

void Delete(Node* head, Node* x)
{
	// When node to be deleted is head node  
	if (head == x)
	{
		if (head->Next == NULL)
		{
			cout << "There is only one node." <<
				" The list can't be made empty ";
			return;
		}

		/* Copy the data of next node to head */
		head->Data = head->Next->Data;

		// store address of next node  
		x = head->Next;

		// Remove the link of next node  
		head->Next = head->Next->Next;

		// free memory  
		free(x);

		return;
	}


	// When not first node, follow  
	// the normal deletion process  

	// find the previous node  
	Node* prev = head;
	while (prev->Next != NULL && prev->Next != x)
		prev = prev->Next;

	// Check if node really exists in Linked List  
	if (prev->Next == NULL)
	{
		cout << "\nGiven node is not present in Linked List";
		return;
	}

	// Removing node
	prev->Next = prev->Next->Next;

	//for memory free
	free(x);

	return;
}

//Inserting Node 
void Insert(Node** head_ref, int new_data)
{
	Node* NewNode = new Node();
	NewNode->Data = new_data;
	NewNode->Next = *head_ref;
	*head_ref = NewNode;
}

/* Utility function to print a linked list */
void Print(Node* head)
{
	while (head != NULL)
	{
		cout << head->Data << " ";
		head = head->Next;
	}
	cout << endl;
}

/* Driver code */
int main()
{
	Node* head = NULL;

	/* Insering values in linked list*/
	Insert(&head, 12);
	Insert(&head, 36);
	Insert(&head, 76);
	Insert(&head, 5);
	Insert(&head, 18);
	Insert(&head, 21);
	Insert(&head, 55);
	Insert(&head, 86);

	cout << "Linked List: ";
	Print(head);

	//Delte the node
	cout << "Node Deleting " << head->Next->Next->Next << " ";
	Delete(head, head->Next->Next);

	//After Delting
	cout << "Linked List: ";
	Print(head);

	//Delteing first node
	cout << "Deleting first node ";
	Delete(head, head);

	cout << "Modified Linked List: ";
	Print(head);
	return 0;
}