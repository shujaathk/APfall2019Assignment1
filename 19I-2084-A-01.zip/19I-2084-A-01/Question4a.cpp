/* Program to insert in a sorted list */
//#include <bits/stdc++.h> 
#include <cstddef>
#include <iostream>
using namespace std;

/* Link list node */
class Node
{
public:
	int data;
	Node* next;
};

 //inserting a new node to linklist.
void InsertNode(Node** head, Node* node_new)
{
	Node* current;
	/* Checking for Head */
	if (*head == NULL || (*head)->data >= node_new->data)
	{
		node_new->next = *head;
		*head = node_new;
	}
	else
	{
		/* Locating node to the inserting position */
		current = *head;
		while (current->next != NULL &&
			current->next->data < node_new->data)
		{
			current = current->next;
		}
		node_new->next = current->next;
		current->next = node_new;
	}
}



Node* NewNode(int data) /* Creating new node*/
{
	
	Node* new_node = new Node();

	
	new_node->data = data;
	new_node->next = NULL;

	return new_node;
}


void Print(Node* head) /* Printing the created linked list */
{
	Node* temp = head;
	while (temp != NULL)
	{
		cout << temp->data << " ";
		temp = temp->next;
	}
}

int main()
{
	//Main function for creating linked list. Assinging values to nodes
	Node* heead = NULL;
	Node* node_new = NewNode(25);
	InsertNode(&heead, node_new);
	node_new = NewNode(45);
	InsertNode(&heead, node_new);
	node_new = NewNode(8);
	InsertNode(&heead, node_new);
	node_new = NewNode(20);
	InsertNode(&heead, node_new);
	node_new = NewNode(1);
	InsertNode(&heead, node_new);
	node_new = NewNode(35);
	InsertNode(&heead, node_new);
	cout << "Linked list\n";
	Print(heead);

	return 0;
}