// APAssingment.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>;
#include "conio.h";
#include "../MyEncryptionLibrary/encryption.h"
#include <sstream>
#include <string>
#include <vector>
#include <iostream>
using namespace std;
using namespace encryption;

void main()
{
	char inputstring[1000];//Intialilzing Charcter datatype with size
	char output[1000] = "";//Intialilzing Charcter datatype with size
	int outputnumeric[1000]; // Intialilzing Numaric datatype with size
	int opt = 0;
	cout << "Enter you String " << endl;
	cin.getline(inputstring, 1000);//Get Input String from user
	cout << "Selct Option" << endl << "1 for Alphabetic Encryption" << endl << "2 for Numaric Encryption" << endl;
	cin >> opt;//Get Selection Input from user for encryption

	for (int i = 0; i < inputstring[i]; i++) {//Loop for every chracter of string
		if (opt == 1) {
			output[i] = AlphabetEncryption(inputstring[i]);//Calling Library Function for encryption
		}
		else if (opt == 2) {
			outputnumeric[i] = NumericEncryption(inputstring[i]);//Calling Library Function for encryption
		}
		else {
			cout << "Please Enter a valid Number" << endl;
		}
	}
	cout << "Encrypted Script is ";
	for (int i = 0; i < output[i]; i++) {
		cout << output[i]; //Getting Alphabetic encrypted String

	}
	for (int i = 0; i < outputnumeric[i]; i++) {
		cout << outputnumeric[i];//Getting Numaric encrypted String
	}
}
