#include <bits/stdc++.h>
using namespace std;
 
/*Standard structure that defines the node*/
struct node
{
   int data;
   node * next;
};
 
/*Function to insert nodes in front of List*/
void InsFront(node **head,int data)
{
   node *temp = new node;
   temp->data = data;
   temp->next = *head;
   *head = temp; 
}
/*Function to swap nodes pairwise*/
void Swap(node **head)
{
   /*If there is 0 or 1 node in linked list*/
   if((*head) == NULL || (*head)->next == NULL)
      return;
   
   /*Initialising all pointers*/
   node *prev = NULL ;
   node *curr = *head;
   node *next = curr->next;
   
   /*Setting new head*/
   *head = next;
   
   /*Loop runs till entire list is traversed*/
   while(curr!= NULL && next!=NULL )
   {   
      /*Swapping links of nodes*/
      curr->next = next->next;
      next->next = curr;
      if(prev!=NULL)
         prev->next = next;
      
      /*Updating pointers to next positions*/
      prev = curr;
      curr = curr->next;
      if(curr!=NULL)
         next = curr->next;
   }
}
/*Function that is used to 
print the Linked List*/
void printList(node *head)
{
  while (head != NULL)
  {
     cout<<head->data<<"-> ";
     head = head->next;
  }
  cout<<"NULL";
}
 
/* Driver program to test above functions*/
int main()
{
  node* head = NULL;
  InsFront(&head, 7);
  InsFront(&head, 9);
  
  cout<<"Original Linked list is:\n";
  printList(head);
  
  /*Calling swap function*/
  Swap(&head);
  cout<<"\nLinked List After Swapping:\n";
  printList(head);
  
  return 0;
}
