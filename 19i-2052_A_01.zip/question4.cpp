/* 
Fatima Rehan
I19-2052
*/

#include <iostream>
using namespace std;

class Node
{ //node
public:
	int data;   // data
	Node *next; // pointer to next
};

class List
{
public:
	List(void)
	{
		head = NULL; // constructor
	}

	bool IsEmpty()
	{
		return head == NULL;
	}
	void InsertNode(int x);
	void DeleteNode(int x);
	void DisplayList(void);

private:
	Node *head;
};

void List::InsertNode(int x)
{ //insert function
	Node *curr = NULL;
	Node *next = head;
	Node *newNode = new Node;
	newNode->data = x;
	if (head == NULL || newNode->data <= head->data)
	{ //Case to follow if value is less than or equal to head
		newNode->next = head;
		head = newNode;
	}
	else
	{
		curr = head;
		while (curr->next != NULL && newNode->data > curr->next->data)
		{ //if value is greater than head, then it finds its respective position
			curr = curr->next;
		}
		newNode->next = curr->next;
		curr->next = newNode;
	}
}

void List::DeleteNode(int x)
{
	Node *prevNode = NULL;
	Node *currNode = head;
	while (currNode && currNode->data != x)
	{ //finds node to be deleted
		prevNode = currNode;
		currNode = currNode->next;
	}
	if (currNode)
	{ //if the node exists, delete.
		if (prevNode)
		{ //the case when node to be deleted is in middle or end
			prevNode->next = currNode->next;
			delete currNode;
		}
		else
		{
			head = currNode->next; //when node to be deleted is at head
			delete currNode;
		}
		cout << "Element deleted." << endl;
	}
	else
	{
		cout << "The element you want to delete does not exist." << endl; //message to display if node doesn't exist
	}
}

void List::DisplayList()
{
	int num = 0;
	Node *currNode = head;
	if (currNode == NULL)
	{
		cout << "List is empty, nothing to print." << endl; //in case list is empty
	}
	else
	{
		while (currNode != NULL)
		{
			cout << currNode->data << "\t";
			currNode = currNode->next;
			num++;
		}
		cout << "\nNumber of nodes in the list: " << num << endl
			 << endl;
	}
}

main()
{
	List list;

	int answer;
	char ch;

	do
	{ //menu to make things easier to run
		cout << "SORTED LINK LIST" << endl;
		cout << "1. Display List" << endl;
		cout << "2. Enter Element in List" << endl;
		cout << "3. Delete element from List" << endl;
		cout << "What would you like to do?" << endl;

		cin >> answer;

		cout << endl;

		switch (answer)
		{
		case 1:
			cout << "Displaying List" << endl;
			list.DisplayList();
			break;

		case 2:
			cout << "Enter an integer value for the element to be added:" << endl;
			int add;
			cin >> add;
			list.InsertNode(add);
			cout << "Element added." << endl;
			break;

		case 3:
			cout << "Enter an integer value of the element to be deleted:" << endl;
			int del;
			cin >> del;
			list.DeleteNode(del);
			break;

		default:
			cout << "You've chosen neither";
		}

		cout << "\nDo you wish to perform another operation?" << endl;
		cout << "Y" << endl;
		cout << "N" << endl;
		cin >> ch;
		cout << endl;
	}

	while (ch == 'Y' || ch == 'y');
}

//end of program
