/* 
Fatima Rehan
I19-2052
*/

#include <iostream>
using namespace std;

class Node
{ //node
public:
	int data;   // data
	Node *next; // pointer to next
};

class List
{
public:
	List(void)
	{
		head = NULL; // constructor
	}

	bool IsEmpty()
	{
		return head == NULL;
	}
	void InsertNode(int x);
	void DisplayList(void);
	void SwapNodes(int x, int y);
	bool FindNode(int x);

private:
	Node *head;
};

void List::InsertNode(int x)
{ //inserts element at end of list
	Node *newNode = new Node;
	newNode->data = x;

	if (head == NULL)
	{
		newNode->next = head;
		head = newNode;
	}

	else
	{
		Node *currNode = head;
		while (currNode->next)
		{
			currNode = currNode->next;
		}

		newNode->next = currNode->next;
		currNode->next = newNode;
	}
}

void List::DisplayList()
{
	int num = 0;
	Node *currNode = head;
	if (currNode == NULL)
	{
		cout << "List is empty, nothing to print." << endl; //in case list is empty
	}
	else
	{
		while (currNode != NULL)
		{
			cout << currNode->data << "\t";
			currNode = currNode->next;
			num++;
		}
		//		cout << "\nNumber of nodes in the list: " << num << endl
		//			 << endl;
	}
}

bool List::FindNode(int x)
{ //see if node element to be deleted actually exists
	Node *currNode = head;
	while (currNode && currNode->data != x)
	{
		currNode = currNode->next;
	}
	if (currNode)
		return true;
	else
	{
		cout << "The node you want does not exist." << endl;
		return false;
	}
}

void List::SwapNodes(int x, int y)
{
	Node *one;
	Node *two;
	Node *temp;

	one = head;
	while (one && one->data != x)
	{
		one = one->next;
	}
	two = head;
	while (two && two->data != y)
	{
		two = two->next;
	}

	swap(one->data, two->data);
}

main()
{
	List list;

	list.InsertNode(1); //insert elements in a list
	list.InsertNode(3);
	list.InsertNode(5);
	list.InsertNode(2);
	list.InsertNode(9);
	list.InsertNode(4);
	list.InsertNode(6);
	list.InsertNode(8);

	int answer1;
	int answer2;
	char ch;

	do
	{ //menu to make things easier to run
		cout << "SWAP VALUES" << endl;
		cout << "List:" << endl;
		list.DisplayList();
		cout << endl;

		cout << "Enter first value to swap:" << endl;
		cin >> answer1;
		cout << endl;
		bool one = list.FindNode(answer1);

		if (one)
		{
			cout << "Enter value to swap first value with:" << endl;
			cin >> answer2;
			cout << endl;
			bool two = list.FindNode(answer2);

			if (two)
			{
				list.SwapNodes(answer1, answer2);

				cout << "List after swapping:" << endl;
				list.DisplayList();
			}
		}
		cout << "\nDo you wish to perform another swapping?" << endl;
		cout << "Y" << endl;
		cout << "N" << endl;
		cin >> ch;
		cout << endl;
	}

	while (ch == 'Y' || ch == 'y');
}

//end of program
