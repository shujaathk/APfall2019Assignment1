/* 
Fatima Rehan
I19-2052
*/

#include <iostream>
#include <fstream>
#include <string.h>

using namespace std;

/* 
gets length of first longest word, 
then checks for words below the longest word length
*/

int main()
{
	int count = 0;
	char check[1000];
	char longestt[1000];
	int originalLongest = 0;
	int loopLongest = 0;
	int next = 0;
	int i = 0;
	int k = 0;
	bool flag = true;
	bool printFlag = false;

	char ch2;
	char words[10000];
	int loop = 0;

	ifstream inFile("sample.txt");	//open file
	while (inFile >> noskipws >> ch2) //read char by char
	{
		words[loop] = ch2; //store in char array
		loop++;
	}

	char *p = words;
	for (; *p != '\0'; ++p)
	{
	}
	int size = p - words;	//get array size to use in loop

	cout << "Top 10 longest words with size:" << endl;

	while (k < 10)
	{
		for (int m = 0; m < size; m++)
		{
			if (next == 0) //getting first longest word
			{
				count++;
				if (words[m] != '.' || words[m] != ',')
					check[i] = words[m];
				i++;
				if (words[m] == ' ')
				{
					if (count > loopLongest)
					{
						printFlag = true;
						loopLongest = count - 1;
						longestt[0] = 0;
						strcpy(longestt, check);
					}
					i = 0;
					count = 0;
				}
			}
			else	//get subsequent longest word
			{
				count++;
				if (words[m] != '.' || words[m] != ',')
					check[i] = words[m];
				i++;
				if (words[m] == ' ')
				{
					if (count <= next)
					{
						if (count >= originalLongest && count >= loopLongest)
						{
							printFlag = true;
							loopLongest = count - 1;
							strcpy(longestt, check);
						}

						else
						{
							loopLongest = originalLongest;
							flag = false;
						}
					}
					i = 0;
					count = 0;
				}
			}
		}

		originalLongest = loopLongest;
		int len;
		if (printFlag)
		{
			cout << k + 1 << ". ";
			for (int j = 0; j < originalLongest; j++)
			{
				cout << longestt[j];
				if (longestt[j] != ' ')
				len = j+1;
				
			}
			cout << " " << len << endl;

			originalLongest--;
			loopLongest = 0;
			printFlag = false;
			k++;
		}
		else if (!flag)
		{
			originalLongest--;
		}

		next = originalLongest;
	}

	return 0;
}
