/* 
Fatima Rehan
I19-2052
*/

#include <iostream>
#include <cstdlib>
#include <fstream>

using namespace std;

/* alphabet to alphabet encryption method */
char *simpleEnc(char *ch)
{
	char capitalOriginal[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	char capitalEncrypted[] = "ZYXWVUTSRQPONMLKJIHGFEDCBA";
	char smallOriginal[] = "abcdefghijklmnopqrstuvwxyz";
	char smallEncrypted[] = "zyxwvutsrqponmlkjihgfedcba";

	char *p = ch;
	for (; *p != '\0'; ++p)
	{
	}
	int arraySize = p - ch; //getting size of array

	for (int i = 0; i < arraySize; i++)
	{
		for (int j = 0; j < sizeof(smallOriginal); j++)
		{
			if (smallOriginal[j] == ch[i])
			{
				ch[i] = smallEncrypted[j]; //swap according to encryption
				break;
			}
			if (capitalOriginal[j] == ch[i])
			{
				ch[i] = capitalEncrypted[j];	//swap according to encryption
				break;
			}
		}
	}

	cout << ch << endl
		 << endl;
	return ch;
}

/* alphabet to alphabet decryption method */
void simpleDec(char *ch)
{
	char capitalOriginal[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	char capitalEncrypted[] = "ZYXWVUTSRQPONMLKJIHGFEDCBA";
	char smallOriginal[] = "abcdefghijklmnopqrstuvwxyz";
	char smallEncrypted[] = "zyxwvutsrqponmlkjihgfedcba";

	char *p = ch;
	for (; *p != '\0'; ++p)
	{
	}
	int arraySize = p - ch;

	for (int i = 0; i < arraySize; i++)
	{
		for (int j = 0; j < sizeof(smallOriginal); j++)
		{
			if (smallEncrypted[j] == ch[i])
			{
				ch[i] = smallOriginal[j];	//swap according to decryption
				break;
			}
			if (capitalEncrypted[j] == ch[i])
			{
				ch[i] = capitalOriginal[j];	//swap according to decryption
				break;
			}
		}
	}

	cout << ch << endl;
}

/* mod 23 encryption method */
int *modEnc(char *ch, int encrypt[])
{
	char *p = ch;
	for (; *p != '\0'; ++p)
	{
	}
	int arraySize = p - ch;

	int chAscii[arraySize];

	for (int i = 0; i < arraySize; i++)
	{
		chAscii[i] = (int)ch[i];

		if (chAscii[i] == 32)
		{
			encrypt[i] = 32;	//catering to spaces
		}
		else if (chAscii[i] >= 97 && chAscii[i] < 120)
		{
			encrypt[i] = chAscii[i] % 23; //applying mod 1st time
		}
		else if ((chAscii[i] >= 65 && chAscii[i] < 69) || (chAscii[i] >= 74 && chAscii[i] < 77))
		{
			encrypt[i] = 23 + (chAscii[i] % 23); // catering to 1st kind of duplication
		}
		else if (chAscii[i] == 69)
		{
			encrypt[i] = 23; //catering to one of the 2 zeros; other zero is left as it is
		}
		else
		{
			encrypt[i] = chAscii[i] % 23 - (chAscii[i] % 23) * 2; // catering to another set of duplication
		}
	}

	for (int i = 0; i < arraySize; i++)
	{
		cout << encrypt[i] << " ";
	}

	cout << endl
		 << endl;
	return encrypt;
}

/* mod 23 decryption method */
void modDec(int seq[], int size)
{
	char decrypt[size];
	for (int i = 0; i < size; i++)
	{
		if (seq[i] == 32)
		{
			decrypt[i] = (char)32;	//spaces
		}
		else if (seq[i] == 0)
		{
			decrypt[i] = (char)115;	//the letter s
		}
		else if (seq[i] > 4 && seq[i] < 23)
		{
			decrypt[i] = (char)(23 * 4 + (seq[i]));
		}
		else if (seq[i] >= 42 && seq[i] < 46)
		{
			decrypt[i] = (char)(23 * 2 + (seq[i] - 23));
		}
		else if (seq[i] >= 28 && seq[i] < 31)
		{
			decrypt[i] = (char)(23 * 3 + (seq[i] - 23));
		}
		else if (seq[i] == 23)
		{
			decrypt[i] = (char)69;
		}
		else if ((seq[i] <= (-5) && seq[i] > (-8)) || seq[i] >= 1 && seq[i] < 5)
		{
			decrypt[i] = (char)(23 * 5 + abs((seq[i])));
		}

		else
		{
			decrypt[i] = (char)(23 * 3 + abs((seq[i])));
		}
	}
	for (int x = 0; x < size; x++)
	{
		cout << decrypt[x];
	}
}

main()
{
	char *ch3;
	int *seq;
	char ch2;
	char ch[10000];
	int loop;

	ifstream inFile("string.txt");	//open file
	while (inFile >> noskipws >> ch2)	//read char by char
	{
		ch[loop] = ch2;	//store in char array
		loop++;
	}

	char *p = ch;
	for (; *p != '\0'; ++p)
	{
	}
	int size = p - ch;

	cout << "String to be encrypted: " << endl;
	cout << ch << endl //original string
		 << endl;	//can only have spaces, no symbols

	cout << "Encrypted using alphabet swap: " << endl;
	ch3 = simpleEnc(ch); //encrypted string stored in ch3 

	cout << "Decrypted using the same method: " << endl;
	simpleDec(ch3); //ch3 recieved from simpleEnc function

	cout << "\nEncrypted using mod of 23: " << endl;
	int encrypt[size]; 
	seq = modEnc(ch, encrypt); //encrypted sequence stored in seq

	cout << "Decrypted using the same method: " << endl;
	modDec(seq, size); //recieved from modEnc function
}
