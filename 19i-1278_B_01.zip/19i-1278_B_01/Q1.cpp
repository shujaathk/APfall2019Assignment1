#define _CRT_SECURE_NO_DEPRECATE
#include <stdio.h>
#include <stdlib.h>
#include<iostream>
#include<map>
using namespace std;

void insertMap(string word, map<int, map<string, int> > &mp)
{
	mp[1][word]++;
}

void display(map<int, map<string, int> > &mp)
{
	for (map<int, map<string, int> >::iterator cit = mp.begin(); cit != mp.end(); ++cit)
	{
		for (map<string, int>::iterator wit = cit->second.begin(); wit != cit->second.end(); ++wit)
			cout << "\tword: " << wit->first << "\t" << wit->second << endl;
	}
}

int main()
{
	FILE* fptr;
	char ch;
	int wrd = 1, charctr = 1;
	char fname[20];
	string storeWords;

	map<int, map<string, int> > mp;

	cout << " Input the filename to be opened : ";
	cin >> fname;

	fptr = fopen(fname, "r");
	if (fptr == NULL)
	{
		cout << " File does not exist or can not be opened.";
	}
	else
	{
		ch = fgetc(fptr);
		cout << " The content of the file are:";
		while (ch != EOF)
		{
			if (ch == ' ' || ch == '\n')
			{
				mp[1][storeWords]++;

				storeWords = "";
				wrd++;
			}
			else
			{
				storeWords += ch;
				charctr++;
			}
			ch = fgetc(fptr);
		}
	}
	fclose(fptr);

//	int countMap = 0;

	display(mp);
}
