//QUESTION #3

//Header files
#include<iostream>
#include<conio.h>
using namespace std;

//Declaring the structure for node;
struct Node {
	int data;
	Node* next;
} *head = new Node();

//Returns the length of the array;
int LengthofList(Node *node) {
	int count = 0;
	while (node != NULL)
	{
		count++;
		node = node->next;
	}
	return count;
}

int ValueCheckFlag(int check)
{
	if (check == 1)
		check = 2;
	else if (check == 0)
		check = 1;

	return check;
}

void displayList(Node *node)
{
	while (node != NULL)
	{
		cout << node->data << "\t\t\t";
		node = node->next;
	}
	cout << "\n\n";
}

//Swapping using data part
void SwapByValue(Node *node, int val1, int val2){
	
	int check = 0;
	Node *temp1 = NULL, *temp2 = new Node();

	while (node != NULL)
	{
		if (val1 != val2)
		{
			//Checking if both values exist in the given List
			if (val1 == node->data)
			{
				check = ValueCheckFlag(check);
				if(check == 2)
				{
					break;
				}
				else
				{
					temp1 = node;
				}
			}
			else if (val2 == node->data)
			{
				check = ValueCheckFlag(check);
				if (check == 2)
				{
					break;
				}
				else
				{
					temp1 = node;
				}
			}
		}
		//Node increment
		node = node->next;
	}
	if (check < 2)
	{
		cout << "Sorry, your values doesnt exist in the list\n\n";
	}
	else
	{
		temp2->data = temp1->data;
		temp1->data = node->data;
		node->data = temp2->data;
	}
}

//Swaping using the pointer part
//void SwapByPointer()
//{
//}


int main()
{
	//Declaration of Nodes
	Node *n1 = new Node();
	Node *n2 = new Node();
	Node *n3 = new Node();
	Node *n4 = new Node();
	Node *n5 = new Node();
	Node *n6 = new Node();

	//Populating data in the node and linking them
	head->data = 11;
	head->next = n1;
	n1->data = 12;
	n1->next = n2;
	n2->data = 13;
	n2->next = n3;
	n3->data = 14;
	n3->next = n4;
	n4->data = 15;
	n4->next = n5;
	n5->data = 16;
	n5->next = n6;
	n6->data = 17;
	n6->next = NULL;

	displayList(head);
	SwapByValue(head, 11, 13);
	displayList(head);
}
