#include<iostream>
#include<conio.h>
#include<fstream>
using namespace std;

int encrypt(char ch)
{
	int asciiVal = int(ch);
	cout<<asciiVal<<'\0';
	cout<<asciiVal%23<<'\0'<<'\n';
	return asciiVal%23;
}

int main()
{
	int size = 100;
	char chStr[size];
	fstream myfile1("encrypted.txt", ios::out);
	
	cout<<"Enter the string\n";
	cin.get(chStr, size);
	
	for(int i=0; i<size; i++)
	{
		if(chStr[i]!='\0')
			myfile1 << encrypt(chStr[i]);
		else
			break;
	}
}
