//Question 4

//Header files
#include<iostream>
#include<conio.h>
using namespace std;

//Declaration of the structure
struct Node {
	int data;
	Node *next;
} *head = NULL;

//Display List
void displayList(Node* node)
{
	while (node != NULL)
	{
		cout << node->data << "\t";
		node = node->next;
	}
	cout << "\n\n";
}

//Insert function declaration *Insertion in sorted way
void Insert(Node* node, int data)
{

	Node *prevNode = NULL, *tempNode;
	Node* newNode = new Node();

	//First entry condition
	if (node == NULL)
	{
		newNode->data = data;
		newNode->next = NULL;
		head = newNode;
	}
	else
	{
		while (node != NULL)
		{
			if (data <= node->data && prevNode == NULL)
			{
				//insertion at the start
				newNode->data = data;
				newNode->next = head;
				head = newNode;
				break;
			}
			else if (data >= node->data && node->next == NULL)
			{
				//Insertion at the end
				newNode->data = data;
				newNode->next = NULL;
				node->next = newNode;
				break;
			}
			else if (data <= node->data && data > prevNode->data && prevNode->next != NULL)
			{
				//Middle Insertion
				newNode->data = data;
				newNode->next = node;
				prevNode->next = newNode;
				break;
			}
			prevNode = node;
			node = node->next;
		}
	}
}

//Delete function declaration
void Delete(Node* node, int data)
{
	Node* prevNode = NULL, *tempNode = NULL;
	bool checkFlag = false;

	while (node != NULL)
	{
		if (data == node->data)
		{
			checkFlag = true;
			break;
		}

		prevNode = node;
		node = node->next;
	}

	if(checkFlag == true)
	{
		//	Begining
		if (prevNode == NULL)
		{
			if (node->next == NULL)
			{
				//deletion in case of only one element in the string
				head = NULL;
			}
			else if (node->next != NULL)
			{
				//if there are more than one elements than the head will shift the next node and the previous node will be deleted
				tempNode = node->next;
				delete head;
				head = tempNode;
			}
		}

		//Middle Deletion
		else if (node->next != NULL && prevNode != NULL)
		{
			tempNode = node;
			prevNode->next = node->next;
			delete tempNode;
		}

		//Last Element
		else if(node->next == NULL && prevNode != NULL)
		{
			prevNode->next = NULL;
			delete node;
		}
	}
	else
	{
		cout << "Sorry! the data you are trying to delete doesnt exists in the current list";
	}
}

int main()
{
	Insert(head, 5);
	displayList(head);
	Insert(head, 2);
	displayList(head);
	Insert(head, 1);
	displayList(head);
	Insert(head, 3);
	displayList(head);

	Delete(head, 3);
	displayList(head);
}
