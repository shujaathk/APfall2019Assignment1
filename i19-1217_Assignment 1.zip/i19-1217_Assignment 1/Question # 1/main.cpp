#include <iostream>
#include <fstream>

using namespace std;

int main()
{

    ifstream inFile;
    inFile.open("Random.txt");
    char words[40];
    int w=0;

    if(inFile.fail()){
        cout << "Your file didn't work";
    }else{
        while(inFile >> words){
                    cout << words << endl;
                }

        }


    inFile.close();



    return 0;
}
