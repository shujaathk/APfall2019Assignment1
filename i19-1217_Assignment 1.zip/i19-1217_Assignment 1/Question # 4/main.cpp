#include <iostream>
using namespace std;

// Structure for Linked List
struct  Node{
    int data;
    Node *next;
};
// creating pointer for Head
struct Node *head=NULL;

// printing Linked list from head till end
void printList(){
struct Node *currentNode;
currentNode = head;
    while(currentNode != NULL){
        cout << currentNode->data << endl;
        currentNode = currentNode->next;
    }
}

void insert(int x){
struct Node *currentNode;
struct Node *previous = NULL;
currentNode = head;

// If list is empty or Node to be inserted is less or equal to head
if(head==NULL || x <= head->data){
    struct Node *temp = new Node;
    temp->data = x;
    temp->next = head;
    head = temp;
}else{
    // if Node inserted is grater than next value of current
    while(currentNode->next != NULL && currentNode->next->data < x){
        previous = currentNode;
        currentNode = currentNode->next;
    }
    // When value is inserted after current value
    struct Node *temp = new Node;
    temp->data = x;
    temp->next = currentNode->next;
    currentNode->next = temp;
}
}

void deleteNode(int x){
    // creating previous and current Node
    struct Node *current = head;
    struct Node *previous = NULL;
    // Finding the node to be deleted
    while(current && current->data != x){
        previous = current;
        current = current->next;
    }
    if(current){
        // If node to be deleted is not Head
        if(previous){
            previous->next = current->next;

        }
        // Delete Head Node
        else{
            head = current->next;

        }
    }

}

int main()
{
    // calling insert and delete functions
    insert(5);
    insert(8);
    insert(3);
    deleteNode(5);
    insert(2);
    deleteNode(3);
    printList();

    return 0;
}
