#include <iostream>
using namespace std;
#include <fstream>

// two character arrays of small and capital letters
    char s[] = "zyxwvutsrqponmlkjihgfedcba";
    char c[] = "ZYXWVUTSRQPONMLKJIHGFEDCBA";

    void partA(char a){
        int ans;
        int smallAlphabet, capital;
        // ascii code of character
        ans = int(a);

        // checking if character is small or capital
       if(ans > 64 && ans < 91){
        capital = ans - 65;
        cout << c[capital] << endl;
       }
        if(ans > 96 && ans < 123){
        smallAlphabet = ans - 97;
        cout << s[smallAlphabet] << endl;
       }
    }

    void partB(char b){
        int ans;
        int smallAlphabet, capital;
        ans = int(b);

        // checking if character is small or capital
        if(ans > 64 && ans < 91){
        capital = ans % 23;
        cout << capital << endl;
       }
        if(ans > 96 && ans < 123){
        smallAlphabet = ans % 23;
        cout << smallAlphabet << endl;
       }

    }

int main()
{
    ifstream inFile;
    // opening a file
    inFile.open("Random.txt");

    // if file fails to open show message
    if(inFile.fail()){
        cout << "Your file didn't work";
    }else{
        char s;
        // reads till end of file
        while(inFile >> s){
        // sending character in file to various functions
            partA(s);

            partB(s);
        }
        }
    inFile.close();
    return 0;
}
