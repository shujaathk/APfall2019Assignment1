#include <iostream>
using namespace std;

// Linked List node
class Node{
public:
    int data;
    Node* next;
};

// method for printing List
void printList(Node* n){
    while(n != NULL){
        cout << n->data << " ";
        n = n->next;
    }
}

void search(Node **head, int a, int b){
    // Creating current & previous node
    Node *currentX = *head, *prevX = NULL;
    Node *currentY = *head, *prevY = NULL;

    // finding first node in List
    while (currentX && currentX->data != a)
    {
        prevX = currentX;
        currentX = currentX->next;
    }

    // // finding second node in List
    while (currentY && currentY->data != b)
    {
        prevY = currentY;
        currentY = currentY->next;
}
    // If node not present in list then simply return to original list
    if (currentX == NULL || currentY == NULL){
    return;
    }

    // If part will execute when node we are looking for is not Head node
    if (prevX != NULL){
        prevX->next = currentY;}
    else {
        *head = currentY;}

    // If part will execute when node we are looking for is not Head node
    if (prevY != NULL){
        prevY->next = currentX;}
    else {
        *head = currentX;}

    // Swapping Next pointers
    Node *temp = currentY->next;
    currentY->next = currentX->next;
    currentX->next = temp;

    }

int main()
{
    // Creating nodes for list
    Node* head=new Node();
    Node* second=new Node();
    Node* third=new Node();
    Node* fourth=new Node();
    Node* temp=new Node();

    // assigning Data and Next
    head->data = 1;
    head->next = second;
    second->data = 2;
    second->next = third;
    third->data = 3;
    third->next = fourth;
    fourth->data = 4;
    fourth->next = NULL;

    int a, b;
  cout << "List: 1, 2, 3, 4" << endl;
  cout << "first node" << endl;
  cin >> a; // Taking user input of first node
  cout << "second node" << endl;
  cin >> b;// Taking user input of second node

  // calling functions
    search(&head, a, b);
    printList(head);

    return 0;
}
