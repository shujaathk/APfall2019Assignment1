#include<iostream>
using namespace std;


struct SLL
{
	int D;
	SLL *N;



	void SW(SLL **hd, int x, int y)
	{
		if (x == y) return;

		SLL *pX = NULL, *cX = *hd;
		while (cX && cX->D != x)
		{
			pX = cX;
			cX = cX->N;
		}

		SLL *pY = NULL, *cY = *hd;
		while (cY && cY->D != y)
		{
			pY = cY;
			cY = cY->N;
		}

		if (cX == NULL || cY == NULL)
			return;

		if (pX != NULL)
			pX->N = cY;
		else 
			*hd = cY;
 
		if (pY != NULL)
			pY->N = cX;
		else 
			*hd = cX;

		SLL *T = cY->N;
		cY->N = cX->N;
		cX->N = T;
	}

	void push(SLL** hd, int ND)
	{
		SLL* Nn = new SLL();

		Nn->D = ND;

		Nn->N = (*hd);

		(*hd) = Nn;
	}

	void printList(SLL *node)
	{
		while (node != NULL)
		{
			cout << node->D << " ";
			node = node->N;
		}
	}

	SLL *SN(SLL *hd, int d) {
		SLL *ptr = NULL;
		while (hd) {
			if (hd->D == d) {
				ptr = hd;
				break;
			}
			hd = hd->N;
		}
		return ptr;
	}

	void DN(SLL *hd, int x) {
		SLL *T = SN(hd, x); // search the node to be deleted
		if (T == NULL) { // x not found
			cout << "Node to be deleted not found ... " << endl;
		}
		else {
			if (T == hd) { // first node is to be deleted
				hd = hd->N;
				delete T;
			}
			else { // node to deleted is an intermediate or last node
				SLL *ptr = hd;
				while (ptr->N != T) {
					ptr = ptr->N;
				}
				ptr->N = T->N;
				delete T;
			}
		}
	}


}a;



int main()
{
	int b, c;
	SLL *lis = NULL;
	
	a.push(&lis, 0);
	top:

	cout << "\n\nmenu \n\n1 --> insertion\n\n2 --> swap\n\n3 --> delition\n\n4 --> print linked list \n\ninput : ";

	int ch = 0;
	cin >> ch;
	if ( ch != 1 && ch != 2 && ch != 3 && ch != 4 )
	{
		goto top;
	}

	
	if (ch==1)
	{
		cout << "vlue to insert : ";
		cin >> b;

		a.push(&lis, b);
	}
	
	if (ch == 2)
	{
		cout << "before swap ";
		a.printList(lis);
		cout << "\nenter value 1 to swap : ";
		cin >> b;
		cout << "enter value 2 to swap : ";
		cin >> c;
		a.SW(&lis, b, c);
	}
	
	if (ch == 3)
	{
		a.DN(lis, b);
		cout << "\nafter swap ";
		a.printList(lis);
		cout << endl << endl;


	}

	if (ch == 4)
	{
		cout << "\nLink List : ";
		a.printList(lis);
		cout << endl << endl;
	}

	system("pause");
	system("cls");
	goto top;
	return 0;
}

