#include<iostream>
using namespace std;


struct SLL
{
	int D;
	SLL *N;



	void SW(SLL **hd, int x, int y)
	{
		if (x == y) return;

		SLL *pX = NULL, *cX = *hd;
		while (cX && cX->D != x)
		{
			pX = cX;
			cX = cX->N;
		}

		SLL *pY = NULL, *cY = *hd;
		while (cY && cY->D != y)
		{
			pY = cY;
			cY = cY->N;
		}

		if (cX == NULL || cY == NULL)
			return;

		if (pX != NULL)
			pX->N = cY;
		else 
			*hd = cY;
 
		if (pY != NULL)
			pY->N = cX;
		else 
			*hd = cX;

		SLL *T = cY->N;
		cY->N = cX->N;
		cX->N = T;
	}

	void push(SLL** hd, int ND)
	{
		SLL* Nn = new SLL();

		Nn->D = ND;

		Nn->N = (*hd);

		(*hd) = Nn;
	}

	void printList(SLL *node)
	{
		while (node != NULL)
		{
			cout << node->D << " ";
			node = node->N;
		}
	}



};



int main()
{
	int b, c;
	SLL *lis = NULL;
	SLL a;
	
	a.push(&lis, 7);
	a.push(&lis, 6);
	a.push(&lis, 5);
	a.push(&lis, 4);
	a.push(&lis, 3);
	a.push(&lis, 2);
	a.push(&lis, 1);

	cout << "before swap ";
	a.printList(lis);
	cout << "\nenter value 1 to swap : ";
	cin >> b;
	cout << "enter value 2 to swap : ";
	cin >> c;
	a.SW(&lis, b, c);

	cout << "\nafter swap ";
	a.printList(lis);
	cout << endl << endl;
	system("pause");
	return 0;
}

