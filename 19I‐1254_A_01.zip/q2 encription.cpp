#include<iostream>
#include <cstring>
#include <string>
#include <stdio.h>
#include <stdlib.h>

#define _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_DEPRECATE
//#define __STDC_WANT_LIB_EXT1__ 1



using namespace std;

char dlet[26] = { 'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z' };
char elet[26] = { 'Z','Y','X','W','V','U','T','S','R','Q','P','O','N','M','L','K','J','I','H','G','F','E','D','C','B','A' };

bool dec();
void enc();
void espin();

int z = 0;

#define x 20
char  in[2000];
char  out[2000];
char t[] = { '@' };

int main()
{
top:
	//menu
	cout << "NOTE\ninput format for encription \n eg: asdf\n eg: ASDFinput format for decription\npair value \n0=00\n1=01\n2=02\n.\n.\n.\n.\n24=24\n25=25\npair value not greater than 25\n eg: 0001022021" << endl<<endl<<endl;

	system("pause");
	system("cls");


	cout << "\nmenu \n\n1 --> encription\n\n2 --> decription\n\ninput : ";

	int ch = 0;
	cin >> ch;
	if (ch != 1 && ch != 2)
	{
		goto top;
	}


	if (ch == 1)
	{
		enc();
	}

	if (ch == 2)
	{
		if (dec())
		{
			cout << "out -> " << out;
		}
	}



	cout << endl << endl;
	system("pause");
	system("cls");


	goto top;

	//strncat_s(in, t, 1);
	//dspin();
	//cout << in << endl;

	return 0;
}

void enc()
{
	cout << "in : ";
	cin >> in;
	strncat_s(in, t, 1);

	espin();
	strncat_s(in, t, 1);
	int a = 0;
	int c = 0;

	cout << "out -> ";
	while (in[a] != '@')
	{
		c = in[a];


		// to to proper encription and decription use %25
		// 23 was used as mentioned in the assighment
		c = c % 26;

		cout << c;

		a++;

	}


}

void espin()
{
	int a = 0;
	int c = 0;
	while (c != '@')
	{
		c = in[a];
		if (c >= 97 && c <= 122)
		{
			c = c - 32;
		}

		c = c % 65;
		in[a] = elet[c];
		a++;


	}



}

bool dec()
{

	cout << "in : ";
	cin >> in;
	//adding @ terminate identifier
	strncat_s(in, t, 1);

	bool o = 1;
	int a = 0, b=0;


	for (int i = 0, j = 0; in[i] != '@'; j++)
	{
		int a = 0, b = 0;

		//char to int as value not ASCI
		a = (in[i] - 48) * 10;
		b = in[++i] - 48;

		//cout << "a : " << a << " b : " << b <<endl;
		i++;

		a = a + b;

		//decripting 2nd fase
		if (a>=13&&a<=25)
		{
			a = a + 52;
		}
		else if (a >= 0 && a <= 12)
		{
			a = a + 78;

		}
		//decript spinning
		a = a - 65;
		
		if ((a<0) || (a>25))
		{
			cout << "invalid input";
			in[i] = '@';
			o = 0;
		}


		out[j] = elet[a];


	}

	return o;

}

