#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include<bits/stdc++.h>
#include <map>
#include <cctype>
#include <time.h>
using namespace std;

char letters[26];
map <char, char> mapLetters; //Map for storing letters for first kind of encryption
map <int, char> mapNum; // this map stores ascii%23 answer for each letter, here values are keys, and letters are values. Used for decryption


//This function inserts letters in a global array so that it can be further used to construct
// maps for encryption decryption.
void storeletters()
{
    char c;
    int i = 0;
    for(c = 'A'; c <= 'Z'; c++)
    {
        letters[i] = c;
        i++;

    }
}
int findMod(char c) // find ascii%mod values for encryption
{
    int val;
    if (c != 'X' && c!= 'Y' && c != 'Z')
        return (int(c))%23;
    else
        return ((int(c)%23)+14); // as values will repeat after x, so higher values are being stored.
}

void makeMap()
{
    storeletters();
    char key;
    char value;
    for (int i = 0; i < 26; i++)
    {
        // for a single iteration, both the maps get updated for every letter.
        key = letters[i];
        value = letters[25-i];
        mapLetters[key] = letters[value];

        int val = findMod(key);
        mapNum[val] = key;

    }
}

void encode()
{
    srand(time(NULL));
    makeMap();
    fstream inFile, outFile;

    inFile.open("encode.txt", ios::in);

    outFile.open("decode.txt",ios::out);

    char c;
    int decide = 0; // a random number, if 0 is there encryption is done by letters, otherwise by ascii values.
    map <char, char>::iterator it;

    if (!inFile)
    {
        cout << "file not found ";

    }
    else
    {
        while(inFile.get(c))
        {
            decide = rand()%2;
            cout << decide;
            if (isalpha(c))
            {
                char v;
                v = (toupper(c)); // converts to homogenized form of upper case
                if (decide == 0) // encode by letter
                {
                    it = mapLetters.find(v);
                    if (it == mapLetters.end())
                        cout << "val not found" ;
                    outFile << it->second;
                }
                else   // encode by number
                    outFile<<findMod(v)<<'*';
            }
            else
                outFile << c;
        }
    }
    //outFile.close();
}



void decode()
{
    makeMap();
    fstream decodeFile, outFile;

    outFile.open("decode.txt", ios::in); // file from where encrypted values will be taken

    decodeFile.open("decode2.txt",ios::out); // file where decrypted values will be stored
    char c;
    map <char, char>::iterator it1; // iterators to ieterate each map
    map <int, char>::iterator it2;

    if (!outFile)
    {
        cout << "file not found ";

    }
    else
    {
        while(outFile.get(c) )
        {
            if (isalpha(c))
            {

                it1 = mapLetters.find(c);
                if (it1 == mapLetters.end())
                    cout << "val not found" ;
                else
                    decodeFile << it1->second;
            }
            else if (c != '*') // this checks number till (*) delimeter is encountered.
            {
                int i = 0;
                int i2 = 10;
                while (c != '*' && isdigit(c) && !outFile.eof() )
                {

                    int iC = c-48;
                    i = iC*i2 + i; // this operation combines incoming characters from text file and make them a digit.
                    outFile.get(c); // keep getting value for while loop to run
                    i2 = 1;

                }
                it2 = mapNum.find(i); // finds the value for the number(key)
                cout << i << endl;
                if (it2 == mapNum.end())
                    cout << "val not found" ;
                else
                    decodeFile<< it2->second;

            }
            else if (c != '*' ) //another check to omit (*) and incoprate spaces and full stops
            {
                decodeFile << c;
            }
        }
    }
}


bool sortbysize(const vector <char> &a, const vector<char> &b)
{
    return a.size() > b.size(); // function which will run over character vector to sort in descending order
}

void findTop10 ()
{
    fstream datafile, sortedF;
    vector <vector <char> >vecWords; // 2d vector of character to store words from the file


    char charArr;
    char charArray[256]; // character for storing words
    vector <char> words;

    datafile.open("sample.txt");
    sortedF.open("sampleout.txt");

    int len = 0;
    if (!datafile)
    {
        cout << "can't open file";
    }

    while (!datafile.eof())
    {
        datafile.get(charArr);
        {
            if(isalpha(charArr)) // as long as alphabets are encountered push them in vector
            {
                words.push_back(charArr);

            }
            else // when a space or anything other letter is encountered, the vector is pushed into main vector, indicating a word has been read
            {
                vecWords.push_back(words);
                words.clear(); // clears the vector to read next word

            }

        }
    }

    sort(vecWords.begin(), vecWords.end(), sortbysize); // sorting the main vector according to their words size or length or character array

    //Removing duplicates from a vector, to store unique value
    vector <vector <char> >::iterator it;
    it = unique(vecWords.begin(), vecWords.end());
    vecWords.resize(distance(vecWords.begin(),it));

    for (int i = 0; i < 10; i++) // loop to print only top ten words
    {
        for (int j = 0; j < vecWords[i].size(); j++)
        {
            sortedF<< vecWords[i][j];
        }
        sortedF << endl;
    }

}

class Node{
    public:
        int data;
        Node* next;
};

class LList
{
    private:
        Node *head;
    public:
        LList(){ head = NULL;}


        void insert_node (int num)
        {
            Node* temp = new Node;
            Node* curr = head;
            Node* prev = NULL;
            temp -> data = num;
            int last_val;

            if (head == NULL || (num < head -> data)) /* /inserting in first node*/
            {

                temp->next = head;
                head = temp;

            }
            else
            {   while (curr != NULL && !(num < curr->data && num > prev->data)) // iterating till the space is found to insert or end is reached
                {
                    prev = curr;
                    curr = curr->next;

                }
                if (curr == NULL) // insert in the last
                {
                    prev->next = temp;
                    temp->next = NULL;

                }
                else // insert in the middle
                {
                    temp -> next = curr;
                    prev-> next = temp;

                }
             }
        }

        void dlt_node(int num)
        {
            Node* prev = NULL;
            Node* curr = head;
            Node* next = NULL;

            if (head->data == num)
            {
                curr = head;
                head = head->next;
                delete curr;
            }
            else
            {
                while (curr->data != num)
                {
                    prev = curr;
                    curr = curr -> next;

                }
                if (curr)
                {
                    prev->next = curr->next;
                    delete curr;
                }

            }
        }

        void swapValues(int val, int val2)
        {
            Node* temp = head;
            Node* temp2 = head;

            while (temp->data != val)
            {
                temp = temp -> next;

            }
             while (temp2->data != val2)
            {

                temp2 = temp2 -> next;

            }


            if (temp && temp2)
            {
                cout << "swapping " << endl;
                swap(temp->data, temp2->data);

            }

        }

        void printNodes()
        {

            Node* curr = head;
            if (head == NULL)
            {
                cout << "NULL";
            }
            else
            {
                while (curr != NULL)
                {
                    cout << "print the nodes: ";
                    cout << curr->data << endl;
                    curr = curr->next;
                }
            }
        }



};
int main()
{
//    LList lst;
//    lst.insert_node(3);
//    lst.insert_node(2);
//    lst.insert_node(5);
//    lst.insert_node(4);
//    lst.printNodes();
//    cout << "after swap" << endl;
//    lst.swapValues(4,2);
//    lst.printNodes();


    encode();
    decode();

    return 0;
}
