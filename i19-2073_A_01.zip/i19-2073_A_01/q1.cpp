//Microsoft (R) C/C++ Optimizing Compiler Version 19.00.23506 for x64

#include <iostream>
#include <cstdlib>
#include <string.h>

using namespace std;


int WL(char w[])
{
    int x= 0;
    int l= 0;
    while (w[x++] != '\0')
    {
        l++;
    }
    return l;
}

//the function used to check the total no words in a text
int TW(char t[])
{
    int c = 0;
    int i = 0;
    for (i = 0; t[i]; i++)
    {
        if ((t[i] == ' ' || t[i] == '.') && t[i + 1] != ' ' && t[i] != '\n' && t[i + 1] != '.')
        {
            c++;
        }
    }
    if (t[i - 1] != ' ' && t[i - 1] != '.')
    {
        c+= 1;
    }
    return c;
}
// this function is  used to find the no of  occurances of each word in the array 
int occurance(char *w[][3], int array_size, char *ptr)
{

    for (int i = 0; i < array_size; i++)
    {
       
        if (strcmp(w[i][0], ptr) == 0)
        {
            return i;
        }
    }
    return -1;
}

//the  function is used to sort  the length of words 
void sorting(char *arr[][3], int size)
{
    int x;
    char *ptr;
    char *temp;
    int j;
    for (int i = 1; i < size; i++)
    {
        x = (int)arr[i][1];
        ptr = arr[i][0];
        temp = arr[i][2];
        j = i - 1;
        while ((x > (int)arr[j][1]) && (j >= 0))
        {
            arr[j + 1][0] = arr[j][0];
            arr[j + 1][1] =arr[j][1];
            arr[j + 1][2] = arr[j][2];
            j = j - 1;
        }
        arr[j + 1][0] = (char *)ptr;
        arr[j + 1][1] = (char *)x;
        arr[j + 1][2] = (char *)temp;
    }
    if (size > 10)
    {
        size = 10;
    }
    for (int i = 0; i < size; i++)
    {
        cout << arr[i][0] <<"--->"<< "occurances= " << (int)arr[i][2]<<" "<< "&"<< " length= " << (int)arr[i][1] << " "
             << endl;
    }
}
//this function is used to split the words
void splitting(char text[])
{
   
    int  wrds = TW(text);
    char *ptr;
    int len = 0;
    int i= 0;
    int flag= 0;

    	char *arr[5000][3]={""}; // Two dimensional pointer array

    //this  function is used to  find the tokens from the string and store in the character pointer
    ptr = strtok(text, "  ,.\n");
    while (ptr != NULL)
    {
        int key = occurance(arr, i, ptr);
        if (key!= -1)
        {
            arr[key][2] = arr[key][2] + 1; 
            flag++;
        }
        else
        {
            arr[i][2] = (char *)(key+ 2);
            arr[i][0] = ptr; //each word length is stored in the array of zero column
            len= WL(arr[i][0]);
            arr[i][1] = (char *)len; 
            i += 1;
        }

        ptr = strtok(NULL, "  ,.\n");
    }

    //this  function sort the array according to the length of words
    sorting(arr, wrds - flag);
}
//main body of the function
int main()
{

    char text[] = " Developed through the technological architecture of electrical engineering and the computational language of mathematics, the science of computer technology has provided considerable recognition .  \n"
                  "Computer science and technological has much to offer in anyone of its many career paths\n"
                 "Computer Science Computer science is one of the fastest growing architecture  career fields in modern history."
               "Whether working with a large multinational corporation or a smaller private company on computer hardware or software in engineering  everyday.";

    splitting(text);

	system("pause"); 
	return 0;
}
