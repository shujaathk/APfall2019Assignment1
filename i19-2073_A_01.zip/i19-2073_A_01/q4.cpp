
#include<iostream>
using namespace std;
class  	Node
{
	public:
	int data;
	Node *next;
	Node* head;
public:
Node(){
	head=NULL;
	}
	//first node insertion
Node *insertnode( int v) {
	Node   *newnode=new Node();
	newnode->data=v;
	newnode->next=NULL;
	return newnode;
}
void sortedlist( Node*NN)  
{  
   Node* current;  
//incase there is only head exist
    if (head== NULL || head->data >= NN->data)  
    {  
      NN->next = head;  
       head= NN;  
    }  
    else
    {  
 
        current = head;  
        //search until value not found
        while (current->next!=NULL &&  
            current->next->data < NN->data)  
        {  
            current = current->next;  
        }  
      NN->next = current->next;  
        current->next = NN;  
    }  
} 
//function to search target value
 Node *searchNode( int key) {
   		Node *tmp = NULL;
   while (head) {
      if (head->data == key) {
         tmp = head;
         break;
      }
      head = head->next;
   }
   return tmp;
}
 //fun to delete node
void deletenode( int x) {
   Node *t= searchNode(x); 
   if (t== NULL) 
   { 
      cout << "Node to be deleted not found " << endl;
   }
   else {
      if (t == head) { 
         head = head->next;
         delete t;
      }
      else { 
         Node *curr = head;
         while (curr->next != t) {
            curr= curr->next;
         }
         curr->next = t->next;
         delete t;
      }
   }
}
//print the list elements
void displaylist()
{
	Node*curr=head;
	while(curr!=NULL)
	{
		cout<<curr->data<<endl;
		curr=curr->next;
	}
}
};
int main()
{
	  Node *nn;//pointer of node
	  Node a;//object of node
	  nn=a.insertnode(6);  
    a.sortedlist(nn);  
    nn = a.insertnode(11);  
    a.sortedlist(nn);
    nn = a.insertnode(7);  
    a.sortedlist(nn);
      nn =a.insertnode(3);  
    a.sortedlist(nn);
       nn = a.insertnode(2);  
    a.sortedlist(nn);
	 cout<<"soretd link list\n";
    a.displaylist(); 
 cout<<"after delete a node from list\n";  
   a.deletenode(2); 
   a.displaylist(); 
	return 0;	
}
