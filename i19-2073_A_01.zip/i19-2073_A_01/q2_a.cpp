#include <iostream>
#include <stdlib.h>
#include <string.h>

using namespace std;

char capleter[26];
char s[26];

//this function is to initalize  the capitalletter  and smallletter Array. 
void initilization()
{
    int t = 65;
    for (int i = 0; i < 26; i++)
    {
        if (i < 13)
        {
            capleter[i] = (char)t;
            s[i] = (char)(t++ + 32);
            if (i + 1 == 13)
                t = 90;
        }
        else
        {
            capleter[i] = (char)t;
            s[i] = (char)(t-- + 32);
        }
    }
}
//function is used to compare the  capital alphabet with array
char capital_letter_Encryption(char ch)
{
    for (int j = 0; j < 26; j++)
    {
        if (j < 13)
        {
        	
            if (ch == capleter[j])
            {
                return capleter[j + 13];
            }
        }
        else
        {
            if (ch == capleter[j])
            {
                return capleter[j - 13];
            }
        }
    }
}
//function is used to compre character with letter store in the smallletterArray **/
char small_letter_Encryption(char ch)
{
    for (int j = 0; j < 26; j++)
    {
        if (j < 13)
        {
            if (ch == s[j])
            {
                return s[j + 13];
            }
        }
        else
        {
            if (ch == s[j])
            {
                return s[j - 13];
            }
        }
    }
}
//this function is used for encryption
char *Encryption(char *text)
{
     initilization(); 
    for (int i = 0; i < strlen(text); i++)
    {
        for (int j = 0; j < 26; j++)
        {
            if (text[i] == capleter[j])
            {
                text[i] = capital_letter_Encryption(text[i]);
                break;
            }
            else if (text[i] == s[j])
            {
                text[i] = small_letter_Encryption(text[i]);
                break;
            }
        }
    }
    return text;
}
int main()
{

    char text[] = ""; 
    int  x;
    cout<<"++++++++++++++++letter to letter encryption+++++++++++++\n";
    cout << "Enter your string : ";
    gets(text);//function to enter the string

    cout << "Encryption :"
         << " " << Encryption(text) << endl; 
         cout<<"!!!!!!!!!!!!!!!!!!!11!!!\n";

    cout << "For Decryption press 1 and press 0 for exit : "<< " ";
    cin >> x;

    if (x == 1)
    {
        cout << "Decryption:"
             << " " << Encryption(text) << endl;
    }
    else//incase o is pressed
    {
        exit;
    }
    
	system("pause");
    return 0;
}
