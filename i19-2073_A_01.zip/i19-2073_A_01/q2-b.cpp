#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <cstdio>

using namespace std;
//this fun is used for encryption
void Encryption(char *txt)
{
    char *array=new char[strlen(txt)];  // strlen return the length of string
    int input;

    for (int i = 0; i < strlen(txt); i++)
    {
        array[i] = (char )((int)txt[i] % 23); 
    }
    cout << "the encrypted string = ";
    for (int i = 0; i < strlen(txt); i++)
        cout << (int)array[i];
    cout << endl
         << "Enter 1 for Decrypt  and 0 for Exit : ";
    cin >> input;
    
    if (input)
    {
    	//if input is given 
    	cout<<"************\n";
        cout << "the decrypted string = ";
        //this loop is used for  decrytion of  number to letter by taking mode of 23
        for (int i = 0; i < strlen(txt); i++)
        {
            cout << (char)(((int)array[i]) + (23 * ((int)txt[i] / 23)));
        }
    }
    else//incase no input return nothing
    {
        return;
    }
}

//main body of program
int main()
{
	cout<<"++++++++ letter to number encryption +++++++++++";
    char text[] = ""; 
    cout << "\nEnter the string : ";
    // string from user
    gets(text); 
	cout<<"***************\n" ;  
    Encryption(text); 
    cout<<endl;
	system("pause");
    return 0;
}
