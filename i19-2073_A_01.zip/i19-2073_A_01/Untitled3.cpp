#include<iostream>
using namespace std;
class  	Node
{
	public:
	int data;
	Node *next;
    Node *head;
public:
 Node(){
	head=NULL;
	}
	//this fun will create first node
void firstnode(int x)
{ 
	Node *node=new Node();
	node->data=x;
	node->next=NULL;
	head=node;

}
//inserting elemnts in list
void insert(int y)
{
	Node *newnode=new Node();
	newnode->data=y;
	newnode->next=head;
	head=newnode;
}
//swpping the two nodes
void swapping(int v1, int v2)
{  
Node *t1= NULL;
Node *currv1= head;
Node *t2 = NULL;
Node *currv2 =  head;    
//if values are same
if (v1== v2) 
return;    
//search for v1 value
while (currv1 && currv1->data != v1)  
{  
    t1 =currv1;  
   currv1 = currv1->next;  
}  
//search for v2 value
while (currv2 && currv2->data != v2)  
{  
    t2 = currv2;  
    currv2 = currv2->next;  
}  
   
if (currv1 == NULL || currv2 == NULL)  //incase no value exist
    return;  
if (t1 != NULL)  
    t1->next = currv2;  
else 
 head= currv2;   
if (t2!= NULL)  
    t2->next = currv1;  
else 
    head = currv1;  
  //swaping the nodes 
Node *temp = currv2->next;  
currv2->next = currv1->next;  
currv1->next = temp;  
}  
  //print list elemnts
void displaylist()
{
	Node *curr=head;
	while(curr!=NULL)
	{
		cout<<curr->data<<endl;
		curr=curr->next;
	}
}};
int main()
{
	Node n;	//object of class node
	n.firstnode(11);
	int a,b;
	n.insert(6);
	n.insert(5);
	n.insert(7);
    n.insert(3);
    n.insert(2);
    cout<<"values in list before swapping\n";
    n.displaylist();
    cout<<"Enter two values for swapping\n";
    cin>>a>>b;
    n.swapping(a,b);
    cout<<"values in list after swapping\n";
    n.displaylist();
	return 0;	
}

