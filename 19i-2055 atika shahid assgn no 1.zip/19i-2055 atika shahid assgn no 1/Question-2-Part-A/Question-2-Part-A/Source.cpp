#include <iostream>
#include <stdlib.h>
#include <string.h>

using namespace std;

char capitalLetter[26];
char smallLetter[26];

/** First we use the function to initilize the capital letter and small letter array. capitalletter represents the capital alphabets and smallLetter represents the small alphabet **/
void Letters()
{
    int start = 65;
    for (int i = 0; i < 26; i++)
    {
        if (i < 13)
        {
            capitalLetter[i] = (char)start;
            smallLetter[i] = (char)(start++ + 32);
            if (i + 1 == 13)
                start = 90;
        }
        else
        {
            capitalLetter[i] = (char)start;
            smallLetter[i] = (char)(start-- + 32);
        }
    }
}
/** capitalEncrypt function is to compare character from the alphabet stored in the capitalletter **/
char capitalEncrypt(char ch)
{
    for (int j = 0; j < 26; j++)
    {
        if (j < 13)
        {
            if (ch == capitalLetter[j])
            {
                return capitalLetter[j + 13];
            }
        }
        else
        {
            if (ch == capitalLetter[j])
            {
                return capitalLetter[j - 13];
            }
        }
    }
}
/** smallEncrypt function is performing same function as capitalencrypt function. **/
char smallEncrypt(char ch)
{
    for (int j = 0; j < 26; j++)
    {
        if (j < 13)
        {
            if (ch == smallLetter[j])
            {
                return smallLetter[j + 13];
            }
        }
        else
        {
            if (ch == smallLetter[j])
            {
                return smallLetter[j - 13];
            }
        }
    }
}
/** To encrypt the given string in the defined format or scheme **/
char *encrypt(char *text)
{
    Letters(); //call the function
    for (int i = 0; i < strlen(text); i++)
    {
        for (int j = 0; j < 26; j++)
        {
            if (text[i] == capitalLetter[j])
            {
                text[i] = capitalEncrypt(text[i]);
                break;
            }
            else if (text[i] == smallLetter[j])
            {
                text[i] = smallEncrypt(text[i]);
                break;
            }
        }
    }
    return text;
}
int main()
{

    char text[] = ""; //Declare character.
    int input;

    cout << "Enter string : ";
    gets(text);

    cout << "Encrypted String is :"
         << " " << encrypt(text) << endl; 

    cout << "Press 1 for again Decrypt the string and 0 for Exit : "
         << " ";
    cin >> input;

    if (input == 1)
    {
        cout << "Decrypted String is :"
             << " " << encrypt(text) << endl;
    }
    else
    {
        exit;
    }

	system("pause");
    return 0;
}
