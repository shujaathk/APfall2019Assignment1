#include <iostream>
#include <stdlib.h>
#include <string.h>

using namespace std;

void encrypt(char *text)
{
        char *arr=new char[strlen(text)];  //here we use a function, to calculate the length of the string and also return the length of the string.
    int input;

    for (int i = 0; i < strlen(text); i++)
    {
        arr[i] = (char )((int)text[i] % 23); //the character in the string convert into integer, and calculate the modulus.
    }
    cout << "Encrypted String is : ";
    for (int i = 0; i < strlen(text); i++)
        cout << (int)arr[i];
    cout << endl
         << "Enter 1 for Decrypt again and 0 for Exit : ";
    cin >> user_input;
    if (user_input)
    {
        cout << "Decrypted String is : ";
        for (int i = 0; i < strlen(text); i++)
        {
            cout << (char)(((int)arr[i]) + (23 * ((int)text[i] / 23)));
        }
    }
    else
    {
        return;
    }
}

int main()
{
    char text[] = ""; //Declare character.
    cout << "Enter any string : ";
    gets(text);    //input from the user.
    encrypt(text); //Call the function
	cout<<endl;

	system("pause");
    return 0;
}
