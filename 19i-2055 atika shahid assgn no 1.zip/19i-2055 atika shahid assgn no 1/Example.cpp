Objects whose gravitational fields are too strong for light to escape were first considered in the 18th century
 by John Michell and Pierre-Simon Laplace.[12] The first modern solution of general relativity that would characterize
 a black hole was found by Karl Schwarzschild in 1916, although its interpretation as a region of space from which nothing