#include<iostream>
using namespace std;
class Node {
public:
	double	data;	
	Node*	next;	
};
class List {
public:
	List(void) { head = NULL; } // constructor
	~List(void);	            // destructor

	bool IsEmpty() { return head == NULL; }
	Node* InsertNode(int index, double x);
	
	int DeleteNode(double x);
	void DisplayList(void);

private:
	Node* head;
};
List::~List(void) {
	Node* ptr1 = head;
	Node* ptr2 = NULL;
	while (ptr1 != NULL)
	{
		ptr2 = ptr1->next;
		delete ptr1; 
		ptr1 = ptr2;
	}
}
void sort(Node* head){
	Node*i, *j;
	int temp;
	for (i = head; i->next != NULL; i = i->next)
	{
		for (j = i->next; j != NULL; j = j->next)
		{
			if (i->data > j->data)
			{
				temp = i->data;
				i->data = j->data;
				j->data = temp;
			}
		}
	}
}
Node* List::InsertNode(int index, double x) {
	if (index < 0) return NULL;

	int currIndex = 1;
	Node* ptr1 = head;
	while (ptr1 && index > currIndex) {
		ptr1 = ptr1->next;
		currIndex++;
	}
	if (index > 0 && ptr1 == NULL) return NULL;

	Node* newNode = new Node;
	newNode->data = x;
	if (index == 0) {
		newNode->next = head;
		head = newNode;
	}
	else {
		newNode->next = ptr1->next;
		ptr1->next = newNode;
	}
	sort(head);
	return newNode;
}
int List::DeleteNode(double x) {
	Node* prevNode = NULL;
	Node* ptr1 = head;
	int currIndex = 1;
	while (ptr1 && ptr1->data != x) {
		prevNode = ptr1;
		ptr1 = ptr1->next;
		currIndex++;
	}
	if (ptr1) {
		if (prevNode) {
			prevNode->next = ptr1->next;
			delete ptr1;
		}
		else {
			head = ptr1->next;
			delete ptr1;
		}
		return currIndex;
	}
	return 0;
}
void List::DisplayList()
{
	int num = 0;
	Node* ptr1 = head;
	while (ptr1 != NULL){
		cout << ptr1->data << endl;
		ptr1 = ptr1->next;
		num++;
	}
	cout << "Number of nodes in the list: " << num << endl;
}
int main(void)
{
	cout << "helloworld" << endl;
	List list;
	list.InsertNode(0, 7.0);
	list.InsertNode(1, 5.0);	
	list.InsertNode(2, 6.0);
	list.InsertNode(3, 1.0);
	list.InsertNode(4, 10.0);


	list.DisplayList();
	list.DeleteNode(6.0);
	list.DisplayList();
	return 0;
}


