#include<iostream>
#include <fstream>
#include <string>
using namespace std;

int main()
{
	int arraysize = 100;
	char myArray[100][25];
	double word[100];
	int num_characters = 0;
	int i = 0,index[10];
	double top[10][2];
	
	fstream myfile("Example.cpp",ios::in);
	if (myfile.is_open())
	{
		while (!myfile.eof())
		{
			int j = 0;
			myfile.get(myArray[i][j]);
			while (myArray[i][j] != ' ')
			{

				j++;
				myfile.get(myArray[i][j]);
			}
			i++;
			num_characters++;

		}
		myfile.close();
	}
	for (int i = 0; i < 100; i++)
	{
		word[i] = 0;
		for (int j = 0; j < 25; j++)
		{
			if (myArray[i][j] < 123 && myArray[i][j]>64)
			{
				word[i] = word[i] + tolower(myArray[i][j]) * (j + 1);             
				                                                                  
			}
		}
	}
	for (int j = 0; j < 10; j++)
	{
		top[j][0] = word[0];
		for (int i = 0; i < 100; i++)
		{
			if (top[j][0] < word[i])
			{
				top[j][0] = word[i];
				index[j] = i;
			}
		}
		top[j][1] = 0;
		for (int i = 0; i < 100; i++)
		{
			if (top[j][0] == word[i])
			{
				word[i] = 0;
				top[j][1]=top[j][1]+1;
			}
		}
		word[index[j]] = 0;
	}
	for (int i = 0; i < 10; i++)
	{
		for (int j = 0; j < 25; j++)
		{
			if (myArray[index[i]][j] < 123 && myArray[index[i]][j]>64)
			{
				cout << myArray[index[i]][j];
			}
		}
		cout << " ->occurences=" << top[i][1] << endl;
	}
	return 0;
}
