#include <iostream>
#include <fstream>
#include <bits/stdc++.h>
#include <cstddef>
#include <iostream>
 
 
using namespace std;
void encryptFile();
void decryptFile();
char getEncrytedCharacter(char val);

int main()
{
	int c;
	while(c!=3){
		cout << "\n\nEnter your choice number :\n1) Encrypt file\n2) Decrypt File\n3) Exit\n\n>";
		cin>>c;
		switch(c){
			case 1:
				encryptFile();
				break;
			case 2:
				decryptFile();
				break;
		}
	}

}

void encryptFile(){

//opening file to read...
fstream readFile;	
//opening file to write...
fstream writeFile;

readFile.open("decryptedtext.txt", ios::in );//This file holds data that needs to be encrypted...
writeFile.open("encryptedtext.txt",ios::out);//This file holds data that needs to be decrypted...

if(!readFile){
	
	//If file is not created already then we create the file here and insert text...
	readFile.open("decryptedtext.txt", ios::app );
	
	//Skipping these line because ambiguous error. prompt was not waiting for input.
	//so now we have to hard code.
	
	
	//char words[250];
	//cout << "Enter some text to write in newly generated file. contents will be encryted afterwards : \n\n";
	//cin.getline(words,250) ;
	string text="this whole text will be encrypted. change it per your will.\n";
	readFile << text;
	readFile.close();
	readFile.open("decryptedtext.txt", ios::in );
}

if(!writeFile){
	cout << "Error opening file to write...";
	exit(0);
}

cout << "Content in file is : \n";
while(!readFile.eof()){
	char name;
	readFile.get(name) ;
	
	cout<< name;
	
	writeFile << getEncrytedCharacter(name);
}

cout << "\n\nFor encryted format open encrytedtext.txt in same folder";


readFile.close();
writeFile.close();

}


void decryptFile(){

//opening file to read...
fstream readFile;	
//opening file to write...
fstream writeFile;

readFile.open("encryptedtext.txt", ios::in );
writeFile.open("decryptedtext.txt",ios::out);

if(!readFile){
	cout << "Error opening encryted file. Please create it first\n\n";
	
	return;
}

if(!writeFile){
	cout << "Error opening file to write...";
	return;
}

cout << "Content in file is : \n";
while(!readFile.eof()){
	char name;
	readFile.get(name) ;
	
	cout<< name;
	
	writeFile << getEncrytedCharacter(name);
}

cout << "\n\nFor decrypted format open decrytedtext.txt in same folder";


readFile.close();
writeFile.close();

}
char getEncrytedCharacter(char val){
	switch(val){
		case 'a':
			return 'z';
			case 'b':
				return 'y';
				case 'c' :
					return 'x';
				case 'd':
					return 'w';
				case 'e':
					return 'v';
				case 'f':
					return 'u';
				case 'g':
					return 't';
				case 'h':
					return 's';
				case 'i':
					return 'r';
				case 'j':
					return 'q';
				case 'k':
					return 'p';
				case 'l':
					return 'o';
				case 'm':
					return 'n';
				case 'n':
					return 'm';
				case 'o':
					return 'l';
				case 'p':
					return 'k';
				case 'q':
					return 'j';
				case 'r':
					return 'i';
				case 's':
					return 'h';
				case 't':
					return 'g';
				case 'u':
					return 'f';
				case 'v':
					return 'e';
				case 'w':
					return 'd';
				case 'x':
					return 'c';
				case 'y':
					return 'b';
				case 'z':
					return 'a';
					default :
						return val;
	}
	//val -= ((val - 'M') * 2) - 1;
		
		return val;
}
