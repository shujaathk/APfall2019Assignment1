#include <bits/stdc++.h>
#include <cstddef>
 #include <iostream>
 
using namespace std; 

class Node{
	public :
		int value;
		Node* next;
};

class LinkedList{
	public :
	Node* head;
	
	LinkedList(void){
		head=NULL;
	}
	
	void InsertIntoSorted(int n){
		
		Node* current = head;
		Node* prev = NULL;
		
		//Iterating unitll the current value is less than new value...
		while (current && current->value < n) {
		prev=current;
		current = current->next;
		}
		
		Node* newNode = new Node;
		newNode->value = n;
		
		if (current==head) {//Checking if the we need to insert before the head...
		newNode->next = head;
		head = newNode;
		}
		else {
			newNode->next = prev->next;
		prev->next = newNode;
		}	
	}
	
	bool Delete(int a){
		cout << "Delete " << a << " in progress...\n";
		if(!contains(a)){
			cout << "list doesnt contain value " << a << "\n";
			return false;
		}
		Node* current=head;
		Node* prev=NULL;
		
		while(current!= NULL && current->value !=a){
			prev=current;
			current=current->next;
		}
		
		if(prev==NULL){ // This means found node is head
				head=current->next;
			free(current);
			
			
		}else{
		Node* temp=current;
			prev->next=current->next;
			free(temp);
		}
		cout << "Delete Successfull...";
	}
	
	void display(){
		cout << "\nCurrent List\n";
		Node* current=head;
		
		while(current!= NULL){
			cout << current->value << "\n";
			current=current->next;
		}
	}
	
	bool contains(int a){
		Node* current=head;
		
		while(current!= NULL){
			if(current->value==a){
				return true;
			}
			current=current->next;
		}
		return false;
	}
	
	bool isEmpty(){
		return head==NULL;
	}	
};
int main() { 
  
  	LinkedList list;
  	
	
	list.InsertIntoSorted(9);
	list.InsertIntoSorted(1);
	list.InsertIntoSorted(8);
	list.InsertIntoSorted(2);
	list.InsertIntoSorted(6);
	list.InsertIntoSorted(7);
	list.display();
	
	list.Delete(7);
	list.display();
	
	system("pause") ;//To stop the user at the end of program. Exit when any key is hit...
} 
