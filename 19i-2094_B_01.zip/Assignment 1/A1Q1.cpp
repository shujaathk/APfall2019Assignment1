#include <iostream>
#include <string.h>
#include <cstring>
#include <fstream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;
void readFromFile();
int main(int argc, char** argv) {
	readFromFile();
	
}

void readFromFile(){
		//char* longstring="This is a long word string environment car.....";
	
		//int position=0;
		int max=0;
		int count=0;
		string maxvalues="";
		string tempstring="";
		
		
		//opening file to read...
		fstream readFile;	

		readFile.open("decryptedtext.txt", ios::in );//This file holds data that needs to be encrypted...

		while(!readFile.eof()){
			char text;
			readFile.get(text);
				if(text != ' ' && text != '.'){
				count++;
				tempstring+=text;
				
			}else{
				if(count> max){
					max=count;
					maxvalues=tempstring+" ";
				}
				count=0;
				tempstring="";
			}
		}
	
	cout << "Largest string is " << maxvalues<<" with size " << max <<"\n";
	
	}

