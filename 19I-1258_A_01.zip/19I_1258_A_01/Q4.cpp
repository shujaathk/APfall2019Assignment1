#include <iostream>
using namespace std;
//creating a list
class node{
	public:
	int data;
	node* next;
	
	node(){
		data=0;
		next=NULL;
	}
};
//function to insert into sorted list
void insert(int num, node *head){
	node *n1= new node();

	n1->data= num;
	n1->next= NULL;
	//if the number to be inserted is smaller than the value in head.
	if (num < head->data){
		n1->next=head;
		head=n1;
	}
	//check if the number to be inserted is less than the value in the current's next, the node will be inserted.
	else{
		node *current= head;
		while (current->next!=NULL && current->next->data < n1->data){
		 	current = current->next;  
		}
		n1->next = current->next;  
        current->next = n1;  
	}
	//to display the new list
	node *t= new node();
	t=head;
	cout<<"the list contain the following data" <<"\n";
	while (t!=NULL)
	{
		cout<<t->data<<"  ";
		t=t->next;
	}
}
//display function to display the list
void display(node *head){
	node *t= new node();
	t=head;
	cout<<"the list contain the following data" <<"\n";
	while (t!=NULL)
	{
		cout<<t->data<<"  ";
		t=t->next;
	}
}
// function to delete a number from the sorted list
void dele(int num, node *head){

	node *temp= new node();
//	node *current= head->next;
	//check if the number to be deleted is present in head than delete it and make the next node head
	if(num==head->data){

		temp=head;
		head=head->next;
		delete(temp);
		return;
	}
	//traverse the list to find the number to delete
	else{
	node *current=head;
	while(current->next!=NULL && current->next->data!=num){
		current= current->next;
		if(current->next==NULL){
			cout<<"Number is not present in the list";
			return;	
		}
		temp=current;
		current=current->next;
		delete(temp);
		return;
	}}
}
int main() {
	// manually creating and adding data into the nodes
	node *head= new node();
   	node *n1= new node();
   	node *n2= new node();
	node *n3= new node();
   	node *n4= new node();
    node *n5= new node();
    
	head->data=5;
    head->next=n1;
   
   	n1->data=8;
   	n1->next=n2;
   	
   	n2->data=12;
   	n2->next=n3;
   	
   	n3->data=17;
   	n3->next=n4;
   	
   	n4->data= 25;
   	n4->next= n5;
   	
   	n5->data= 45;
   	n5->next=NULL;
   	
   	display (head);
   	int num;
   	cout << "\nEnter a number to insert into linked list\n";
   	cin >> num;// getting a number from user to insert in the sorted list
   	insert(num, head);
   	int del;
   	cout << "\nEnter a number to delete\n";
   	cin >> num;// getting a number from user to delete from sorted list
   	dele(num, head);
   	display(head);
} 
