#include <iostream>
using namespace std;
//creating a list
class node{
	public:
	int data;
	node* next;
	
	node(){
		data=0;
		next=NULL;
	}
};
//function to display list
void display(node *head){
	node *t= new node();// a temp node that is used to traverse the list
	t=head;
	cout<<"\nThe list contain the following data" <<"\n";
	while (t!=NULL)
	{
		cout<<t->data<<"  ";
		t=t->next;
	}
}
//function to swapp the nodes of the list.
void swapp(node *head, int value1, int value2){
	//check if both the values to swap are same
	if (value1 == value2)
	{
		cout<<"\nSwapping is not possible both the numbers are same\n";
		return ;
	}
	node *next1= head;
	node *next2= head;
	node *prev1=NULL;
	node *prev2=NULL;
	node *temp= new node();
	//loop will traverse the list to search the 1st node
	while (next1 !=NULL && next1->data!=value1){
		prev1=next1;
		next1=next1->next;
		if(next1->data==value1){
			break;
		}
	}
	// loop will traverse the list to find the second node
	while (next2 !=NULL && next2->data!= value2){
		prev2=next2;
		next2=next2->next;
		if (next2->data==value2){
			break;
		}
	}
	//cout<<"\nvalue1 "<<next1->data;
	//cout<<"\nvalue 2 "<<next2->data;
	
	//swapping of the nodes by using a temp node.
	if(next1->data==value1 && next2->data==value2){
		temp->data=next1->data;
		next1->data= next2->data;
		next2->data=temp->data;
		}
		else{
			cout<<"\n Swapping is not possible";
		}
	}
		
int main() {
	//manually creating and adding data into the nodes
	node *head= new node();
   	node *n1= new node();
   	node *n2= new node();
	node *n3= new node();
   	node *n4= new node();
    node *n5= new node();
    
	head->data=5;
    head->next=n1;
   
   	n1->data=8;
   	n1->next=n2;
   	
   	n2->data= 2;
   	n2->next=n3;
   	
   	n3->data=7;
   	n3->next=n4;
   	
   	n4->data= 25;
   	n4->next= n5;
   	
   	n5->data= 17;
   	n5->next=NULL;
   	
	display(head);// calling the dispaly function to display the list before swapping
   
   	int v1; 
	int v2;
   
   	cout<<"\nEnter the value 1 to swap\n";
   	cin>> v1;// getting the number from user to swap
   	cout <<"Enter value 2 to swap\n";
   	cin>> v2;// getting 2nd number from user to swap
   
   	swapp (head, v1 ,v2);//calling swap function
   
   	display(head);// calling dispaly fuction to display the list after swapping
} 
