#include<conio.h>
#include<iostream>
#include<stdlib.h>
#include<bits/stdc++.h>
using namespace std;
struct lng{
	int length;
	char words[8];
};
// count the total words in a file
int length(FILE *p){
    int len=0;
    int c=0;
    char s;
    while( (s=fgetc(p))!= EOF){
 			if ((s==' ')||(s=='\n')||(s==',')||(s=='.')) 
 			{	
			 if(c!=0){ // to get rid of charatcer count. we only need word count for declaring and array
			  len++; // 1 increament after 1 word count
 				c=0;} 
			}
			 else c++; // to save total words in a word
			 }
			 cout<< "length"<< len;
	return len;
} // determine length and string 
	 void sorting(struct lng file[30], int t)
		{
			struct lng temp; //temporary Array for swap the values 
			for( int i=0; i <t;i++)
			{
				for (int j=0; j<(t-1-i);j++)
				{
					if(file[j].length<file[j+1].length) // comparison 
					{
						temp=file[j];
						file[j]=file[j+1];
						file[j+1]=temp;
					}
				}
			}
		// to display top 10 Words with its length 
			for( int z=0; z<10; z++)
	{
		cout<<endl<<file[z].words;
		cout<<"\t\t"<<file[z].length;
		}
	}
	void str(FILE * p, struct lng A[], int total){
	int i=0;
	int j=0;
	int z=0;
	char s=' ';
		while( (s=fgetc(p))!= EOF){
 			if ((s==' ')||(s=='\n')||(s==',')||(s=='.')) //  delimiter 
 			{
 			
			 	A[i].length=j; // if delimiter appear previous word will be save, i will be move to next word 
				i++;
 				j=0; //j will be zero to start the word from beginsing 
			}	
			else
			{
			 A[i].words[j]=s;
			 j++;}
			 }
			 // display all words 
	for( int z=0; z<total; z++)
	{
		cout<<endl<<A[z].words;
		cout<<"\t\t\t"<<A[z].length;
		}
		
}
		
int main()
{
	FILE *p=fopen("enc.txt","r"); // open a file
	int total=length(p);	// count word 
	struct lng A[total];	// make struture array according to word length 
	fclose(p);				// close a file 
	FILE *FF=fopen("enc.txt","r");  // open file again to perform separate operation 
	str(FF,A,total); // to show the word with length
	cout<<"\n\n\t\t TOP 10 NUMBERS \n\n";
	cout<<" WORDS\t\t LENGTH\n";
	sorting(A,total); // show the top 10 words in Ascending order 
	fclose(FF);
	getch();
	return 0;
	
}
