#include<conio.h>
#include<iostream>
using namespace std;
class Node{
	private:
		int data;
		Node * next;
		Node *head=NULL;
		public:
			void insert(int a){ // insert elements in linklist 
					Node * n=new Node();
					n->data=a;
					n->next=head;
					head=n;
				
			}
			void swap (int a, int b){
				Node *first=head; 		// for searching first element  
				Node *second=head; 		// for searching second element 
				while (first!=NULL && first->data!=a)
						first=first->next;	
				if(first==NULL)
				{
					cout<< " \n First element does not exist\n";
				}
				while(second !=NULL && second->data!=b)
					second=second->next;	
				if(second==NULL)
				{
					cout<< " \n Second element does not exist\n";
				}		
				int t; // temporary element for swapping 
				t=first->data;
				first->data=second->data;
				second->data=t;
				}
			void display(){
				Node * y=head;
				while(y!=NULL){
					cout<<"\n Number\t"<<y->data<<endl;
					y=y->next;
				}
			}
};
int main (){
	Node n;	// create object for the linklist 
	int a, b; 
	n.insert(2);
	n.insert(1);
	n.insert(5);
	n.insert(6);
	cout<<"values before swpping ";
	n.display();
	cout<<" \nEnter first number for swapping\t";
	cin>>a;
	cout<<" \nEnter second number\t ";
	cin>>b;
	n.swap(a,b);
	cout<<"\nvalues after swpping ";
	n.display();
	getch();
	return 0;
}
