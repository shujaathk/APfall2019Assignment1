#include<conio.h>
#include<iostream>
using namespace std;
void encrypt(FILE *p)
{
	char s;
	int y;
	int t,a=0;
	FILE *R;
	R=fopen("result2.txt","w");	
	while((s = fgetc(p)) != EOF) // while invalid character not reached 
	{
		if ((s==' ')||(s=='\n')||(s=='.')||(s==','))
		fprintf(R,"%c",s); // store it as it is
		else if (isalpha(s)) // if it is an alphabet (capital letter )
		{
		t= (int(s))%23; // mod of ascii code with 23
		if(int(s)>88 && int(s)<=90 ) // if mod repeat its cycle 
			t= t*(-1); // store negattive of that mod
		fprintf(R,"%d", t); // store resulted value in a resultant file 
		fprintf(R,"%c",'#'); // seperator that distiguish either it a single digit or 2 digit
		}}
	fclose(R);
	FILE *Si; // display result 
	Si=fopen("result2.txt","r");	
	while((s = fgetc(Si))!=EOF)
		cout<<s;
	fclose(Si);
}
int main()
{
	FILE *f;
	f=fopen("SAMPLE.txt","r");
	encrypt(f);	
	getch();
	return 0;
}
 
