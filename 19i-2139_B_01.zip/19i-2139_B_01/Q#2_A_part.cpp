#include<conio.h>
#include<iostream>
#include <fstream>
using namespace std;

int main(){
	char s, t;
	int i=0;
	int c=0;
	
	// for counting character in a file 
	
fstream file("enc.txt",ios::in);
while (!file.eof())
{
		file.get(s);
    		cout<<s;
    		c++; // count the characters
    	}
    	cout<< " \n\n\n total length of character in a file \t\t"<<c<<endl;
    	cout<<endl<<"\n";
  file.close();
  
  // for enrcrption/decryption of the character
  
fstream file2("enc.txt", ios::in); // input file
fstream result("result.txt",ios::out); // resultant file 
// if you want to decrypt data change the fle names  results will be decode accordingly 
char A[c];
while (!file2.eof())
{
	file2.get(s);
	if ((s==' ')||(s=='\n')||(s=='.')||(s==',')) // if any delimiter appers , it remains same 
	 		A[i]=s;
		else if(s>='A'&& s<='Z') 				// if capital letters appear , it convert into backword capital alphabet ( A to Z, Z to A etc)
	 		A[i]='A'+'Z'-(s);
	 	else if( s>='a'&& s<='z') 				// if small letters appear, itt will be converted to backward small letter  a to z , z to a etc)
	 		A[i]='a'+'z'-s;
	result.put(A[i]); 							// store the encrypted charatcer to resulted file
	i++;
	 	}
file2.close();
result.close();

//display result 
fstream file4("result.txt", ios::in);
while (!file4.eof())
{
		file4.get(s);
    		cout<<s;
    	}
  file4.close();
	 
getch();
return 0;
}

