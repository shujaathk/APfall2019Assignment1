#include<conio.h>
#include<iostream>
using namespace std;
class Node {
	private:
	int data;
	Node *next;
	Node *head=NULL;
	public:
		void create(int a) // first Node in the list 
		{
			Node *n= new Node(); // create first node
			n->data=a;
			n->next=NULL;
			head=n;			
		}
	void insert(int a){ // insert element in the sorted order 
					Node * n=new Node();
					n->data=a;
					Node * pre=NULL;
					Node * curr=head;
					while((curr!=NULL)&&(curr->data < n->data))	{ // compare data of of each node 
						pre=curr;
						curr=curr->next;
					}
					n->next=curr;
					if(curr==head) // if insertion point is at fisrt location 
						head=n; // change the head
					else 
						pre->next=n;	// change the link of the previous node to the new one 
		}
		void del(int a){
			Node * temp = head;
			Node *pre=NULL;
			while ( temp->next!=NULL){
				if(temp->data==a){ 
					if(pre!=NULL)
						pre->next = temp->next; // when the node other than the first
					else
						head=head->next; //for the first node
					delete temp;	// delete target node
					break;
				}
				pre=temp;		// keep record for the previous one 
				temp=temp->next; // move to the next node 
		}
	}
	void display(){
				Node * y=head;
				while(y!=NULL){
					cout<<"\n Number\t"<<y->data<<endl;
					y=y->next;} 
		}
};
int main(){
	Node n;
	bool reply;
	int a;
	n.create(3); // create linklist
	cout<< "First element in the list :\t";
	n.display();
	Insert:	
	cout<<"Do you want to insert in the sorted list (1 for yes/ 0 for no)";
	cin>>reply;
	if(reply)
	{
		cout<<"\n Enter number\t ";
		cin>>a;
		n.insert(a);
		goto Insert;
	}
	
	n.display();
	Delete:
	cout<<"Do you want to delete from the list (1 for yes/ 0 for no)";
	cin>>reply;
	if(reply)
	{
		cout<<"\n Enter number to delete \t ";
		cin>>a;
		n.del(a);
		goto Delete;
	}

	cout<<" \nAfter Deletion\t";
	n.display();
	getch();
	return 0;
}
	
