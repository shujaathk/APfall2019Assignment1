#include <iostream>
#include <fstream>
#include<conio.h>
#include "Filehandling.h"
using namespace std;
int main()
{
	mycustomFile file;
	char ch;
	int count = 0;
	int length = file.Lengthoffile();
	char *arraycontent = new char[length]; 
	ifstream filereader("Myfile.txt"); 
	if (filereader.fail()) //checking if file has any errors
	{
		cout << "Error while opening" << endl;
		exit(1);
	}
	while (filereader >> noskipws >> ch) //reading string character by character including white spaces
	{
		if (ch != -52)
		{
			arraycontent[count] = ch;// adding content of text file to character array
			count++;
		}
	}
	arraycontent[count] = '\0';
	cout<<"--------Encrypted string is-----------:"<< endl;
	cout<< endl;
	file.Encryptstring(arraycontent);
	cout << endl;
	cout << "--------Decrypted string is:---------" << endl;
	cout << endl;
	file.Decryptstring(arraycontent);
	_getch();
}