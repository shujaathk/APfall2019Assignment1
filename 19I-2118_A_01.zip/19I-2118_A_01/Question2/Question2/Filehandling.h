#include <iostream>
#include <fstream>
using namespace std;
const char Lowercharacter[] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
const char Capitalcharacter[] = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
class  mycustomFile
{
public:
	 mycustomFile();
	~mycustomFile();
	int Lengthoffile();
	void Encryptstring(char *);
	void Decryptstring(char *);
};

mycustomFile:: mycustomFile()
{
}

 mycustomFile::~ mycustomFile()
{
}

 int mycustomFile::Lengthoffile()
 {
	 ifstream  inputFile("Myfile.txt");
	 int length = 0;
	 if (inputFile.fail())
	 {
		 cout<<"Error while opening"<<endl;
		 return length;
	 }
	 char ch;
	 while (!inputFile.eof())
	 {
		 inputFile>>noskipws>>ch;
		 length++;
	 }
	 inputFile.close();
	 return length;

 }
 void mycustomFile::Encryptstring(char *ch)//This function takes char pointer to char array and encrypt string using scheme 1.
 {
	 cout << "\t";
	 for (; *ch != '\0';)//infinite loop till end of string
	 {
		 if (int(*ch) >= 65 && int(*ch) <= 90)//checking for capital characters and applying encryption scheme
		 {
			 int n = 90 - int(*ch);
			 *ch = Capitalcharacter[n];
		 }
		 else if (int(*ch) >= 97 && int(*ch) <= 122)//checking for lower case characters and applying encryption scheme
		 {
			 int n = 122 - int(*ch);
			 *ch = Lowercharacter[n];
		 }
		 cout << *ch;
		 ch++;
	 }
 }
 void mycustomFile::Decryptstring(char *ch)//This function takes char pointer to char array and decrypt string using scheme 1.
 {
	 cout << "\t";
	 for (; *ch != '\0';)//infinite loop till end of encrypted string
	 {
		 if (int(*ch) >= 65 && int(*ch) <= 90) // decrypting string
		 {
			 int n = 90 - int(*ch) + 65;
			 *ch = n;
		 }
		 else if (int(*ch) >= 97 && int(*ch) <= 122)
		 {
			 int n = 122 - int(*ch) + 97;
			 *ch = n;
		 }
		 cout << *ch;
		 ch++; //pointing pointer to next location
	 }
 }