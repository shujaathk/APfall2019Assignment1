#include <iostream>
#include "Listfile.h"
#include<conio.h>
using namespace std;
int main()
{
	SinglyList list; // creating object of list
	list.InsertNode(0, 21);
	list.InsertNode(1, 26);
	list.InsertNode(2, 11); //adding nodes to list
	list.InsertNode(3, 65);
	list.InsertNode(4, 77);
	list.InsertNode(5, 82);
	list.InsertNode(6, 7);
	list.DisplayList();
	list.swapnodes(11, 7);   //calling swap function of list
	cout << "--------After swapping values-------" << endl;
	list.DisplayList();   //list is displayed after swapping the nodes
	_getch();
}