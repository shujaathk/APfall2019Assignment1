#include <iostream>
using namespace std;

class Node{   //node class which contain data and pointer to node 
public:
	double data;
	Node*  next;
};
class SinglyList{
private:
	Node* head;
public:
	SinglyList()
	{
		head = NULL;
	}
	bool IsEmpty() { return head == NULL; }  

	Node* InsertNode(int index, double value);     //declaration of functions

	int DeleteNode(double value);

	void DisplayList(void);
	void swapnodes(double value1, double value2);
};
Node* SinglyList::InsertNode(int index, double value) {

	if (index < 0) return NULL;

	int currIndex = 1;

	Node* currNode = head;

	while (currNode && index > currIndex) {

		currNode = currNode->next;

		currIndex++;

	}

	if (index > 0 && currNode == NULL) return NULL;

	Node* newNode = new Node;

	newNode->data = value;

	if (index == 0) {

		newNode->next = head;

		head = newNode;

	}

	else {

		newNode->next = currNode->next;

		currNode->next = newNode;

	}

	return newNode;

}

void SinglyList::DisplayList()

{

	int num = 0;

	Node* currNode = head;

	while (currNode != NULL){

		cout << currNode->data <<"\t";

		currNode = currNode->next;

		num++;

	}
	cout <<endl;
	cout << "Total nodes in list are: " << num << endl;

}

void SinglyList::swapnodes(double value1, double value2)  //takes two values to swap
{
	if (value1 == value2 || IsEmpty()){   //if both values are same return 
		return;
	}
	Node* prevNodeX = NULL;
	Node* currNodeX = head; 
	while (currNodeX && currNodeX->data != value1){  //iterating through eachs nodes till value 1
		prevNodeX = currNodeX;
		currNodeX = currNodeX->next;
	}
	Node* prevNodeY = NULL;
	Node* currNodeY = head;
	while (currNodeY && currNodeY->data != value2){ //iterating through each node till value 2
		prevNodeY = currNodeY;
		currNodeY = currNodeY->next;
	}
	if (currNodeX == NULL || currNodeY == NULL){
		return;
	}
	if (prevNodeX != NULL)
	{
		prevNodeX->next = currNodeY;
	}
	else
	{
		head = currNodeY;
	}
	if (prevNodeY != NULL)
	{
		prevNodeY->next = currNodeX;
	}
	else
	{
		head = currNodeX;
	}
	Node* temp = currNodeY->next;
	currNodeY->next = currNodeX->next;   //changing the addresses of nodes
	currNodeX->next = temp;   
}