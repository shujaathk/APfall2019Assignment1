#include <iostream>
#include <fstream>
#include <cstring>
#include "FileHandling.h"
#include<conio.h>
using namespace std;
int main()
{
	File file;
	int size = file.lengthoffile();
	char *arr = new char[size];
	ifstream  inputFile("Myfile.txt");

	if (inputFile.fail())
	{
		cout << "Error in opening file" << endl;
		exit(1);
	}
	char ch;
	int count = 0;
	while (inputFile >> noskipws >> ch)
	{
		//inputFile >>noskipws>> ch;
		if (ch != -52)
		{

			arr[count] = ch;
			count++;
		}


	}
	arr[count] = '\0';
	char str[] = "- This, a sample string.";
	ofstream ostream("maximum.txt");
	ostream << "";
	ostream.close();
	char delim[] = " .";
	char *next_token1 = NULL;
	char * pch;
	pch = strtok_s(file.copyingarray(arr, count), delim, &next_token1);
	int strsize = 0;
	while (pch != NULL)
	{
		if (strsize == 0)
		{

			ofstream ostream("maximum.txt", ios::app);
			ostream << pch << "\n";
			ostream.close();
			char *ptr = file.DisplayUniqueWord(pch, count, file.copyingarray(next_token1, count), &strsize);
			cout << ptr;
		}
		pch = NULL;
	}
	_getch();
}