#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
class File{
public:
  int lengthoffile();
  char* toLower(char*);
  bool checkingDuplicate(char*);
  int stringlength(char*);
  int Totaloccurance(char*, char[]);
  char* copyingarray(char*, int);
  char* File::DisplayUniqueWord(char*, int, char*, int*);
};
int File::lengthoffile()
{
	ifstream  inputFile("Myfile.txt");
	int size = 0;
	if (inputFile.fail())
	{
		cout << "Error in opening file" << endl;
		return size;
	}
	char ch;
	while (!inputFile.eof())
	{
		inputFile >> noskipws >> ch; //readinf character by character and finding size of file
		size++;
	}
	inputFile.close();
	return size;

}
char* File::toLower(char *ptr)
{
	for (int i = 0; ptr[i] != '\0'; i++)
	{
		ptr[i] = tolower(ptr[i]);   //converting char ptr to lower characters
	}
	return ptr;
}
bool File::checkingDuplicate(char *pr)
{
	ifstream istream("maximum.txt", ios::in);
	char ptr[50];
	while (istream >> ptr)
	{
		if (strcmp(toLower(ptr), toLower(pr)) == 0)
		{
			istream.close();
			return false;
		}
	}
	return true;
}
char* File::DisplayUniqueWord(char *str, int count, char *nextpart, int *maxLength)
{
	char delim[] = " .";
	if (str != NULL)
	{
		char *pr = copyingarray(nextpart, count);
		char *next_token1 = NULL;
		char * pch;
		char *maxstr = str;
		int mazLength = stringlength(str);

		pch = strtok_s(nextpart, delim, &next_token1);
		int tOccur = 0;

		while (pch != NULL)
		{
			if (checkingDuplicate(pch))
			{
				ofstream ostream("maximum.txt", ios::app);
				ostream << pch << "\n";
				ostream.close();
			}
			pch = strtok_s(NULL, delim, &next_token1);
		}
		return maxstr;
	}
}
int File::stringlength(char *str)
{
	int count = 0;
	for (int i = 0; str[i] != '\0'; i++)
	{
		if (str[i] != '.')
			count++;
	}
	return count;
}

int File::Totaloccurance(char *pch, char arr[])
{
	int count = 0;

	char delim[] = " .";
	char *next_token1 = NULL;
	char * pch1;
	pch1 = strtok_s(arr, delim, &next_token1);
	while (pch1 != NULL)
	{
		if (pch1 == pch)
		{
			count++;
		}
		pch1 = strtok_s(NULL, delim, &next_token1);
	}

	return count;
}
char* File::copyingarray(char *sr, int count)
{
	char *ch = new char[count];
	int i = 0;
	for (i = 0; sr[i] != '\0'; i++)
	{
		ch[i] = sr[i];
	}
	ch[i] = '\0';
	return ch;
}