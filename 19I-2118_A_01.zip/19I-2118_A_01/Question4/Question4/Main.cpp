#include <iostream>
#include "Listfile.h"
#include<conio.h>
using namespace std;
int main()
{
	SinglyList list;  //creating object of list
	list.InsertNode(3);
	list.InsertNode(18);
	list.InsertNode(7);
	list.InsertNode(24);
	list.InsertNode(32);
	list.InsertNode(72);
	list.InsertNode(34);
	cout << "------List before deletion of node------" << endl;
	list.DisplayList();
	list.DeleteNode(24);//deleting node with value 24
	cout << "----List After deletion of node-----" << endl;
	list.DisplayList(); //list after node deletion
	_getch();
}