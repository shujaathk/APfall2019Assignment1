#include <iostream>
using namespace std;
class Node{  //node class with  data and pointer to node
public:
	double data;
	Node*  next;
};
class SinglyList{
private:
	Node* head;   
public:

	//constructor of SinglyList class
	SinglyList()
	{
		head = NULL;
	}

	//declaration of functions


	void DeleteNode(double);
	bool IsEmpty() { return head == NULL; }
	void InsertNode(double);
	void DisplayList(void);
};

void SinglyList::DeleteNode(double value) { //taking value of node to delete

	if (head == NULL){ //if no node in list returning null;
		return;
	}
	int currentIndex = 1;
	Node* prevNode = NULL;
	Node* currNode = head;   //assigning head to pointer which is going to iterate
	while (currNode && currNode->data != value) { //iterating till value found
		prevNode = currNode;    //assigning address of value node to another node
		currNode = currNode->next; // 
		currentIndex++;
	}
	if (currNode == NULL){ //
		return;
	}
	if (currNode){ //if current node is not null
		if (prevNode){
			prevNode->next = currNode->next; //address is assignng to prev node and deleting currnode;
			delete currNode;
		}
		else{
			head = currNode->next;  
			delete currNode;
		}
	}
	return;
}

void SinglyList::DisplayList()

{

	int totalcount = 0;

	Node* currNode = head;

	while (currNode != NULL){

		cout << currNode->data <<"\t";

		currNode = currNode->next;

		totalcount++;

	}
	cout <<endl;
	cout << "Total nodes in the list: " << totalcount << endl;

}



void SinglyList::InsertNode(double value) {

	Node* newNode = new Node();
	newNode->data = value;
	if (head == NULL){
		newNode->next = head;
		head = newNode;
		return;
	}
	Node* prevNode=NULL;
	Node* currNode = head;
	while (currNode && currNode->data<value) {
		prevNode = currNode;
		currNode = currNode->next;

	}
	newNode->next = prevNode->next;
	prevNode->next = newNode;
}