
#include "pch.h"
#include <iostream>
#include <string>
#include <fstream>
#include <streambuf>

using namespace std;

int main()
{

	int fsize = SizeOfFile();
	char *arr = new char[fsize];
	ifstream  inputFile("F://a.txt");

	if (inputFile.fail())
	{
		cout << "Error in opening file" << endl;
		exit(1);
	}
	char ch;
	int count = 0;
	while (inputFile >> noskipws >> ch)
	{
		if (ch != -52)
		{

			arr[count] = ch;
			count++;
		}
	}
	arr[count] = '\0';
	EncryptFunction(arr);
	cout << "Encryptd String : " << endl;
	
	DecryptFunction(arr);
}

//this function will encrypt the character
void EncryptFunction(char *a)
{
	//adding characters in characterarray
	char CapitalLetters[] = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
	char SmallLetters[] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
	for (; *a!='\0'; )  // for loop check characters on the base of ascii value
	{
		if (int(*a) >= 65 && int(*a) <= 90)
		{
			int n= 90 - int(*a);
			*a = CapitalLetters[n];
		}
		else if (int(*a) >= 97 && int(*a) <= 122)
		{
			int n = 122 - int(*a);
		*a = SmallLetters[n];
		}
		
		cout << *a;
		a++;
	}

}

//function will return the size of file
int SizeOfFile()
{
	ifstream  inputFile("F://a.txt");
	int fsize = 0;
	if (inputFile.fail())
	{
		cout << "Error in opening file" << endl;
		return fsize;
	}
	char ch;
	while (!inputFile.eof())
	{
		inputFile >> noskipws >> ch;
		fsize++;
	}
	inputFile.close();
	return fsize;
}

//function will decrypt the characters
void DecryptFunction(char *a)
{
	cout << "Decrypted String" << endl;
	char CapitalLetters[] = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
	for (; *a != '\0'; )  // note 2
	{
		if (int(*a) >= 65 && int(*a) <= 90)
		{
			int n = 90 - int(*a) + 65;
			*a = n;
		}
		else if (int(*a) >= 97 && int(*a) <= 122)
		{
			int n = 122 - int(*a) + 97;
			*a = n;
		}
		cout << *a;
		a++;
	}
}
