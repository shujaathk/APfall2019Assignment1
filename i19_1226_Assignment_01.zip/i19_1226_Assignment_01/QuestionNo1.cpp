
#include "pch.h"
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;

//function will convert capital letters to lower letters
char* ConverttoLower(char *ptr)
{
	for (int i = 0; ptr[i] != '\0'; i++)
	{
		ptr[i] = ConverttoLower(ptr[i]);
	}
	return ptr;
}
//fuction will check duplicate letters
bool checkDuplicate(char *pr)
{
	ifstream istream("F://maximum.txt",ios::in);
	char ptr[50];
	while (istream >> ptr)
	{
		if (strcmp(ConverttoLower(ptr), ConverttoLower(pr)) == 0)
		{
			istream.close();
			return false;
		}
	}
	return true;
}
//function will return count of all occrences
int AllOccurance(char *pch, char arr[])
{
	int count = 0;

	char delim[] = " .";
	char *next_token1 = NULL;
	char * pch1;
	pch1 = strtok_s(arr, delim, &next_token1);
	while (pch1 != NULL)
	{
		if (pch1 == pch)
		{
			count++;
		}
		pch1 = strtok_s(NULL, delim, &next_token1);
	}

	return count;
}
char* DisplayUnique(char *str, int count, char *nextpart, int *mazLength);
//function will return the length of string
int strLength(char *str)
{
	int count = 0;
	for (int i = 0; str[i] != '\0'; i++)
	{
		if (str[i] != '.')
			count++;
	}
	return count;
}
//function will return all the occurences
int AllOccurance(char *pch, char arr[])
{
	int count = 0;

	char delim[] = " .";
	char *next_token1 = NULL;
	char * pch1;
	pch1 = strtok_s(arr, delim, &next_token1);
	while (pch1 != NULL)
	{
		if (pch1 == pch)
		{
			count++;
		}
		pch1 = strtok_s(NULL, delim, &next_token1);
	}

	return count;
}
char* copyArray(char *sr,int count)
{
	char *ch = new char[count];
	int i=0;
	for (i = 0; sr[i] != '\0'; i++)
	{
		ch[i] = sr[i];
	}
	ch[i] = '\0';
	return ch;
}
//this method will return unique characters
char* DisplayUnique(char *str, int count, char *nextpart, int *maxLength)
{
	char delim[] = " .";
	if (str != NULL)
	{
		char *pr = copyArray(nextpart, count);
			char *next_token1 = NULL;
			char * pch;
			char *maxstr=str;
			int mazLength = strLength(str);
			
			pch = strtok_s(nextpart, delim, &next_token1);
			int tOccur = 0;
			
			while (pch != NULL)
			{
				if (checkDuplicate(pch))
				{
					ofstream ostream("D://max.txt", ios::app);
					ostream << pch << "\n";
					ostream.close();
				}
				pch = strtok_s(NULL, delim, &next_token1);
			}
			return maxstr;
	}
}

//this method will return the size of file
int SizeOfFile()
{
	ifstream  inputFile("F://bbc.txt");
	int fsize = 0;
		if (inputFile.fail())
		{
			cout << "Error occured" << endl;
			return fsize;
		}
		char ch;
	while (!inputFile.eof())
	{
		fsize++;
	}
	inputFile.close();
	return fsize;

}
int main()
{
	int size = SizeOfFile();
	char *arr = new char[size];
	//read the file
	ifstream  inputFile("D://alpha.txt");
	//if file not read
	if (inputFile.fail())
	{
		cout << "Error in opening file" << endl;
		exit(1);
	}
	char chr;
	int count = 0;
	//while input contains character
	while (inputFile >> noskipws >> chr)
	{
		if (chr != -52)
		{
			
			arr[count] = chr;
			count++;
		}

		
	}
	arr[count] = '\0';
	char str[] = "- This, a sample string, sdfds.";
	//output file stream
	ofstream ostream("F://maximum.txt");
	ostream << "";
	ostream.close();
	char delim[] = " .";
	char *next_token1 = NULL;
	char * pchr;
	pchr = strtok_s(copyArray(arr, count) , delim,&next_token1);
	int strsize = 0;
	while (pchr != NULL)
	{
		if (strsize == 0)
		{
		
		ofstream ostream("F://maximum.txt", ios::app);
		ostream << pchr << "\n";
		ostream.close();
		char *ptr = DisplayUnique(pchr, count, copyArray(next_token1, count), &strsize);
	   }
		pch = NULL;

	}
    std::cout << "Hello World!\n"<<count;

}
