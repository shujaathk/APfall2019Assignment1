

#include <iostream>

using namespace std;
//Node class consist of node parts
class Node{
    public:
    double data;
    Node*  next;
};
//class named list consist of declaration of functions
class List{
    private:
    Node* head;
    public:
    List(void)
    {
        head==NULL;
    }
    bool IsEmpty() { return head == NULL; }

    void InsertNode(double x);

    void DeleteNode(double x);

    void DisplayList(void);
};

//function will retuen all list
void List::DisplayList()

{

int num= 0;

Node* currNode =head;

while (currNode != NULL){

cout << currNode->data << endl;

currNode = currNode->next;

num++;

}

cout << "Number of nodes in the list: " << num << endl;

}


//function will take parameter that will contail data of node
void List::InsertNode(double x) {

Node* newNode=new Node();
newNode->data=x;
//insert at first
if(head==NULL){
    newNode->next=head;
    head=newNode;
    return;
}
//find the location to insert
Node* prevNode;
Node* currNode =head;
while (currNode && currNode->data<x) {
prevNode=currNode;
currNode= currNode->next;

}
//add new node at searched new location
newNode->next =prevNode->next;
prevNode->next=newNode;
}

//function will take value tobe delete
void List::DeleteNode(double x) {
//check list exist or not
if(head==NULL){
    return;
}

int currentIndex=1;
Node* prevNode=NULL;
Node* currNode =head;
//find the node tobe delete
while (currNode && currNode->data!=x) {
prevNode=currNode;
currNode= currNode->next;
currentIndex++;
}
//check node searched or not
if(currNode==NULL){
    return;
}
//delete the node
if(currNode){
 if(prevNode){
    prevNode->next=currNode->next;
    delete currNode;
}
else{
    head=currNode->next;
    delete currNode;
}
}
return;
}
int main()
{
List a ;

a.InsertNode(8);
a.InsertNode(10);
a.InsertNode(9);
a.InsertNode(81);
a.InsertNode(11);
a.DisplayList();
a.DeleteNode(11);

a.DisplayList();
}
