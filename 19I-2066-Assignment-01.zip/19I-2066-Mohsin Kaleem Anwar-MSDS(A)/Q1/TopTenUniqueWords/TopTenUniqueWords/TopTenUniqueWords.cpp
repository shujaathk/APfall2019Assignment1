// FileRead.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
int FileSize();
char* DisplayUniqueWord(char *str, int count, char *nextpart, int *mazLength);
char* copyArray(char *sr, int count);
bool checkDuplicate(char *pr);
char* toLower(char *ptr);

int strLength(char *str);

int TotalOccurance(char *pch, char arr[]);

int main()
{
	int size = FileSize();
	char *arr = new char[size];
	ifstream  inputFile("D://alpha.txt");

	if (inputFile.fail())
	{
		cout << "Error in opening file" << endl;
		exit(1);
	}
	char ch;
	int count = 0;
	while (inputFile >> noskipws >> ch)
	{
		//inputFile >>noskipws>> ch;
		if (ch != -52)
		{

			arr[count] = ch;
			count++;
		}


	}
	arr[count] = '\0';
	char str[] = "- This, a sample string, sdfds.";
	ofstream ostream("D://max.txt");
	ostream << "";
	ostream.close();
	char delim[] = " .";
	char *next_token1 = NULL;
	char * pch; \
		pch = strtok_s(copyArray(arr, count), delim, &next_token1);
	int strsize = 0;
	if (strsize == 0)
	{

		ofstream ostream("D://max.txt", ios::app);
		ostream << strLength(pch) << " " << pch << "\n";
		ostream.close();
		char *ptr = DisplayUniqueWord(pch, count, copyArray(next_token1, count), &strsize);
	}
	// char *ptr=DisplayUniqueWord(pch, count, copyArray(next_token1, count), &strsize);

}
int FileSize()
{
	ifstream  inputFile("D://alpha.txt");
	int size = 0;
	if (inputFile.fail())
	{
		cout << "Error in opening file" << endl;
		return size;
	}
	char ch;
	while (!inputFile.eof())
	{
		inputFile >> noskipws >> ch;
		size++;
	}
	inputFile.close();
	return size;

}
char* DisplayUniqueWord(char *str, int count, char *nextpart, int *maxLength)
{
	char delim[] = " .";
	if (str != NULL)
	{
		char *pr = copyArray(nextpart, count);
		char *next_token1 = NULL;
		char * pch;
		char *maxstr = str;
		int mazLength = strLength(str);
		pch = strtok_s(nextpart, delim, &next_token1);
		int tOccur = 0;

		while (pch != NULL)
		{
			if (checkDuplicate(pch))
			{
				ofstream ostream("D://max.txt", ios::app);
				ostream << strLength(pch) << " " << pch << "\n";
				ostream.close();
			}
			pch = strtok_s(NULL, delim, &next_token1);
		}
		return maxstr;
	}
}

char* copyArray(char *sr, int count)
{
	char *ch = new char[count];
	int i = 0;
	for (i = 0; sr[i] != '\0'; i++)
	{
		ch[i] = sr[i];
	}
	ch[i] = '\0';
	return ch;
}
bool checkDuplicate(char *pr)
{
	ifstream istream("D://max.txt", ios::in);
	char ptr[50];
	while (istream >> ptr)
	{
		if (strcmp(toLower(ptr), toLower(pr)) == 0)
		{
			istream.close();
			return false;
		}
	}
	return true;
}

int TotalOccurance(char *pch, char arr[])
{
	int count = 0;

	char delim[] = " .";
	char *next_token1 = NULL;
	char * pch1;
	pch1 = strtok_s(arr, delim, &next_token1);
	while (pch1 != NULL)
	{
		if (strcmp(toLower(pch1), toLower(pch)) == 0)
		{
			count++;
		}
		pch1 = strtok_s(NULL, delim, &next_token1);
	}

	return count;
}
int strLength(char *str)
{
	int count = 0;
	for (int i = 0; str[i] != '\0'; i++)
	{
		if (str[i] != '.')
			count++;
	}
	return count;
}
char* toLower(char *ptr)
{
	for (int i = 0; ptr[i] != '\0'; i++)
	{
		ptr[i] = tolower(ptr[i]);
	}
	return ptr;
}