// InsertDeleteNode.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
using namespace std;
class Node {
public:
	int data;
	Node*  next;
};
class List {

public:
public:
	List(void)
	{
		head == NULL;
	}
	Node* CreateNode(int data)
	{
		Node* newNode = new Node;

		newNode->data = data;
		return newNode;
	}
	void InsertNode(int index, int x) {

		//Call function for create new node
		Node* tempNewNode = CreateNode(x);
		if (head != NULL)
		{

			Node* currenNode = head;
			//if new node data less than existing first node data than add node at first position
			if (x < currenNode->data)
			{
				tempNewNode->next = currenNode;
				//currenNode->next = tempNewNode;
				head = tempNewNode;
			}
			else
			{
				//find node position and insert new node
				while (currenNode->next != NULL && x > currenNode->next->data)
				{
					currenNode = currenNode->next;
				}
				tempNewNode->next = currenNode->next;
				currenNode->next = tempNewNode;
			}


		}
		else
		{

			//if no node exist than create first  node
			tempNewNode->next = NULL;
			head = tempNewNode;
		}

	}
	void DeleteNode(int x)
	{
		//check if no node exist than return control
		if (head == NULL)
		{
			cout << "No node exist in a List" << endl;
			return;
		}
		else
		{
			Node *prevNode = head;
			Node *temp;
			//if node first position than delete and move head to next node
			if (prevNode->data == x)
			{
				temp = prevNode;
				head = prevNode->next;
				delete temp;
			}
			else
			{
				//find previous node 
				while (prevNode->next != NULL && prevNode->next->data != x)
				{
					prevNode = prevNode->next;
				}
				//strre node for delete
				temp = prevNode->next;
				prevNode ->next = prevNode->next->next;
				//delete node
				delete temp;
			}
		}
	}

	void ShowList()
	{
		Node* Temp = head;

		while (Temp != NULL) {

			cout << Temp->data << " -> ";

			Temp = Temp->next;
		}
		cout << "NULL";
	}

private:
	Node  *head;
};
void main()
{
	List list;
	cout << "Insert Some Nodes In List" << endl;
	list.InsertNode(4, 45);
	list.InsertNode(4, 55);
	list.InsertNode(0, 5);
	list.InsertNode(1, 15);

	list.InsertNode(3, 35);
	list.InsertNode(2, 25);

	list.InsertNode(5, 65);
	list.DeleteNode(35);
	list.DeleteNode(65);
	cout << "\nBefore Swap List" << endl;
	list.ShowList();
	system("pause");
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
