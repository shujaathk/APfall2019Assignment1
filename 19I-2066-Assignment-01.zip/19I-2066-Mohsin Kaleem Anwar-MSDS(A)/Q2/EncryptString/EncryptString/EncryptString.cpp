// TopUniqueWords.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
#include <string>
#include <fstream>
#include <streambuf>

using namespace std;
int FileSize();
void Encrypt(char *c, char *CapitalAlphabets, char *smallAlphabets);
void decrypt(char *c);


int main()
{
	// Array for encrypt string read from file
	char CapitalAlphabets[] = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
	char smallAlphabets[] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };

	//get file size
	int size = FileSize();
	//create dynamic array  for store file data
	char *arr = new char[size];
	//open file for read content
	ifstream  inputFile("D://alpha.txt");
	//Open File For read content inside file
	if (inputFile.fail())
	{
		cout << "Error in opening file" << endl;
		exit(1);
	}
	char ch;
	int count = 0;
	//read file char by char and store in char array;
	while (inputFile >> noskipws >> ch)
	{
		//inputFile >>noskipws>> ch;
		if (ch != -52)
		{

			arr[count] = ch;
			count++;
		}


	}
	arr[count] = '\0';
	// call function for encrypt string
	cout << "Encryptd String : " << endl;
	Encrypt(arr, CapitalAlphabets, smallAlphabets);
	// call function for decrypt string
	cout << "Dcrypt String : " << endl;
	decrypt(arr);

}

int FileSize()
{
	//Open File For read content inside file
	ifstream  inputFile("D://alpha.txt");
	int size = 0;

	//if file have some error
	if (inputFile.fail())
	{
		cout << "Error in opening file" << endl;
		return size;
	}
	//Read charecter by charecter and increment in size + 1
	char ch;
	while (!inputFile.eof())
	{
		inputFile >> noskipws >> ch;
		size++;
	}
	inputFile.close();


	// return file size;
	return size;

}
void Encrypt(char *c, char *CapitalAlphabets, char *smallAlphabets)
{
	while (*c != '\0')
	{
		//read char in array if char is capital letter than formula calculate oposite letter index and get char for
		 //capital alphabets array

		int maxAchiiCodeforCapitalLetter = 90;  //Z achii code 90
		int maxAchiiCodeforsmallletter = 122;//z achii code 122

		if (int(*c) >= 65 && int(*c) <= 90)
		{
			//formula for get index of letter for encrypt e.g. A=Z
			int n = maxAchiiCodeforCapitalLetter - int(*c);
			*c = CapitalAlphabets[n];
		}
		else if (int(*c) >= 97 && int(*c) <= 122)
		{
			//formula for get index of letter for encrypt e.g. a=z
			int n = maxAchiiCodeforsmallletter - int(*c);
			*c = smallAlphabets[n];
		}

		cout << *c;
		c++;
	}

}

void decrypt(char *c)
{
	cout << "Decrypted String" << endl;
	int minAchiiCodeforCapitalLetter = 65;  //A achii code 65

	int minAchiiCodeforSmallLetter = 97;  //a achii code 97

	int maxAchiiCodeforCapitalLetter = 90;  //Z achii code 90
	int maxAchiiCodeforsmallletter = 122;//z achii code 122
	while (*c != '\0')
	{
		if (*c >= 65 && *c <= 90)
		{
			//get achhi code for dcrypt string e.g Replace Z to A
			//fromula MaxAchhi-charachii+minachii for capital latters
			int n = maxAchiiCodeforCapitalLetter - *c + minAchiiCodeforCapitalLetter;
			*c = n;
		}
		else if (*c >= 97 && *c <= 122)
		{
			//fromula MaxAchhi-charachii+minachii for capital latters
			int n = maxAchiiCodeforsmallletter - *c + minAchiiCodeforSmallLetter;
			*c = n;
		}
		cout << *c;
		c++;
	}
}

