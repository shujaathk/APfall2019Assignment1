


#include "pch.h"

#include <iostream>

	using namespace std;

class Node {
public:
	int data;
	Node*  next;
};
class List {

public:
	List(void)
	{
		head == NULL;
	}

	//Create Node and Return
	Node* CreateNode(int data)
	{
		Node* newNode = new Node;

		newNode->data = data;
		return newNode;
	}
	Node* AddNode(int index, int data) {
		//if Index is less then 0 and return null pointer
		if (index < 0) return NULL;

		int currIndex = 1;

		Node* currNode = head;
		//if more than one node exist than find and move particular position
		while (currNode && index > currIndex) {

			currNode = currNode->next;

			currIndex++;

		}
		//if index is greate than one but no node exist than return Null
		if (index > 0 && currNode == NULL) return NULL;

		Node *newNode = CreateNode(data);
		//Create node first position if index is Zero
		if (index == 0) {

			newNode->next = head;

			head = newNode;

		}

		else {

			newNode->next = currNode->next;

			currNode->next = newNode;

		}

		return newNode;

	}

	void ShowList()
	{
		//Show List data in list
		Node* Temp = head;

		while (Temp != NULL) {

			cout << Temp->data <<" -> ";

			Temp = Temp->next;
		}
		cout << "NULL";
	}
	void FindNodesForSwap(int a, int b)
	{
		if (head == NULL)
		{
			cout << "No Node Exist in List";
			return;
		}
		else
		{
			//Create Pointer for find node for a and previous node for a and also for b
			Node *ANode, *APrevNode, *BNode, *BPrevNode;
			//move from Head node to next
			ANode = BNode = head;
			APrevNode = BPrevNode = NULL;
			while (ANode!=NULL&& ANode->data!=a)
			{
				APrevNode = ANode;
				ANode = ANode->next;
			}
			//no node exist for a data than return
			if (ANode == NULL)
			{
				cout << a << " Node Not Exist in List Swaping not possible";
				return;
			}
			while (BNode != NULL && BNode->data != b)
			{
				BPrevNode = BNode;
				BNode = BNode->next;
			}
			//no node exist for b data than return
			if (BNode == NULL)
			{
				cout << b << " Node Not Exist in List Swaping not possible";
				return;
			}

			//create connection for swap node to previous node for a
			if (APrevNode != NULL)
				APrevNode->next = BNode;
			else 
				head = BNode;

			//create connection for swap node to previous node for b
			if (BPrevNode != NULL)
				BPrevNode->next = ANode;
			else 
				head = ANode;
			 //call function for 2 nodes 
			SwapTwoNode(ANode, BNode);

		}
	}
	void SwapTwoNode(Node *NodeA, Node *NodeB)
	{
		Node *temp = NodeB->next;
		NodeB->next = NodeA->next;
		NodeA->next = temp;
	}

	private:
		Node  *head;
};



void main()
{
	List list;

	//Add Some Nodes in List 
	cout << "Insert Some Nodes In List" << endl;
     list.AddNode(0, 5);
     list.AddNode(1, 15);
     list.AddNode(2, 25);
     list.AddNode(3, 35);
	 list.AddNode(4, 45);
	 list.AddNode(4, 55);
	 list.AddNode(5, 65);
	 //Display List Before Swaping Operation
	cout << "\nBefore Swap List" << endl;
	  list.ShowList();
	cout << "\nAfter Swap List" << endl;
       //Find Nodes and swap if node find in list
	    list.FindNodesForSwap(25, 55);
		//Display List After Swaping Operation
	    list.ShowList();
		system("pause");
}
