#include "pch.h"

#include <iostream>

using namespace std;
int main()
{
	cout << "dhfkjds";
}