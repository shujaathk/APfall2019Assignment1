
#include <iostream>

using namespace std;
//Node class consist of node parts
class Node{
    public:
    double data;
    
    Node*  next;
};
//class named list consist of declaration of functions
class List{
    private:
    Node* head;
    public:
    List(void)
    {
        head==NULL;
    }
    bool IsEmpty() { return head == NULL; }

    Node* InsertNode(int index, double x);

    int DeleteNode(double x);

    void DisplayList(void);
    void swap(double x, double y);
};

//function will take 2 parameters one is index where node will add and second parameter will contail data of node
Node* List::InsertNode(int index, double x) {
//if index will less than zero will return null b/c first node contains 0 index 
if (index < 0) return NULL;

int currIndex =1;

Node* currNode =head;
//while check currentnode contains some data and parametered index is greater than index of linklist
while (currNode && index > currIndex) {

currNode= currNode->next;

currIndex++;

}

if (index > 0 && currNode == NULL) return NULL;
//create new node at specific searched location
Node* newNode = new Node;

newNode->data = x;
//if insertion at start
if (index == 0) {

newNode->next =head;

head=newNode;

}
//if insertion at other than start
else {

newNode->next =currNode->next;

currNode->next =newNode;

}

return newNode;

}
//function will retuen all list
void List::DisplayList()

{

int num= 0;

Node* currNode =head;

while (currNode != NULL){

cout << currNode->data << endl;

currNode = currNode->next;

num++;

}

cout << "Number of nodes in the list: " << num << endl;

}
//function will take 2 parameters which is to be swaped
void List::swap(double x,double y)
{
	//check voth are same or linklist exists
	if(x==y ||IsEmpty()){
		return;
	}
	//find first parameter value from linklist
	Node* prevNodeX =NULL;
	Node* currNodeX=head;
	while(currNodeX && currNodeX->data!=x){
		prevNodeX=currNodeX;
		currNodeX=currNodeX->next;
	}
	//find second parameter value from linklist
	Node* prevNodeY =NULL;
	Node* currNodeY=head;
	while(currNodeY && currNodeY->data!=y){
		prevNodeY=currNodeY;
		currNodeY=currNodeY->next;
	}
	//both nodes exists or not
	if(currNodeX==NULL||currNodeY==NULL){
		return;
	}
	if(prevNodeX!=NULL)
	{
		prevNodeX->next=currNodeY;
	}
	else
	{
		head=currNodeY;
	}
		if(prevNodeY!=NULL)
	{
		prevNodeY->next=currNodeX;
	}
	else
	{
		head=currNodeX;
	}
	//swap nodes
	Node* temp =currNodeY->next;
	currNodeY->next=currNodeX->next;
	currNodeX->next=temp;
}
int main()
{
List a ;

a.InsertNode(0,8);
a.InsertNode(1,9);
a.InsertNode(2,10);
a.InsertNode(3,11);
a.InsertNode(4,81);
a.DisplayList();
a.swap(10,81);
a.DisplayList();
}
