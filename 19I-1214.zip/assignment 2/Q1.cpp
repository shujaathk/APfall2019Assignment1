function hello (strArr) { //function
var newArr = [];    //array intialize
for (var i = 0; i < strArr.length; i++) { //using for loop
var str = strArr[i].trim(); //trim is for remove spacing in the string
if (str.indexOf(' ') > -1)
newArr = newArr.concat(str.split(/\s+/)); //using split to count words in array and concat to joining the array.
else
newArr.push(str);      
}
return newArr;
}
console.log(hello(["my name", "issalmanasad"]);

