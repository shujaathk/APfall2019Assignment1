#include<iostream>
#include <fstream>
using namespace std;

char* Convert(char c, char *code){
	int x = c;
	int modVal = x%23;
//	char code[2];
//	cout<<modVal;
	
	if(modVal < 10){
	code[0] = '0';
	code[1]	= (char)modVal;
	}
	else
	{
		
		int val1 = modVal % 10;
		int val2 = modVal / 10;
		
	//	cout<<val1<<"\t"<<val2<<endl;
		char z = (char)(val1);
		code[0] = (char)val1+48;
		code[1] = (char)val2+48;
		cout<<code[0]<<"\t"<<code[1]<<endl;
	}
	
	return code;
}


int main(){
	
	char c;
	ifstream myfile ("q2.txt");
	if (myfile.is_open())
  {
  	

   while ( myfile.get(c) )
    {
    	char code[3];
    	code[0]= code[1] = '0';
    	code[2] = '\0';
    	
    	char *p;
		p = Convert(c, code);
    //	cout<<c<<"\t"<<*(p)<<*(p+1)<<endl;
    }
    
    myfile.close();
    
  }
  else 
  	cout << "Unable to open file";
	
	return 0;
}
