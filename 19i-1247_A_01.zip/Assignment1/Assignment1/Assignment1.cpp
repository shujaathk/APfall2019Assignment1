#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include<fstream>
#include <ctype.h>
#include<cstring>

using namespace std;


//Question 2 part 1+2 (a) This function can be used for both encryption and decryption
void encrypt_decrypt_scheme1(char*& x, int k) {


	const int n = 26;   //no. of alphabets

	//for mapping 
	char letters[n] = { 'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z' };

	bool upperFlag = 0;  //for handling upper case lettere

	for (int i = 0; i < k; i++) { //loop through the string

		bool isup = 0;

		if (isalpha(*(x + i))) {  //ignore spaces, punctuations and digits

			if (isupper(*(x + i))) {  //to keep track of the uppercase letters 
				isup = 1;
			}

			for (int j = 0; j < n; j++) {   //get index from the mapping

				if (*(x + i) == letters[j] || tolower(*(x + i)) == letters[j]) { //converts both upper and lower case letters

					if (isup) {
						*(x + i) = toupper(letters[n - j - 1]);  //returns the uppercase characters  
						break;
					}
					else {
						*(x + i) = letters[n - j - 1];  //returns the lowercase letters 
						break;
					}
				}
			}

		}
	}

	ofstream ofile("encrypted_scheme1.txt");  //open a file
	ofile.write(x, k);  //save the content in file
	ofile.close(); //close file

}

//Question 2 part 1b
void encryptionscheme2(char*& x, int k) {  //encrypting with schheme 2

	ofstream ofile("encrypted_scheme2.txt");  //open the file to write 

	for (int i = 0; i < k; i++) {

		ofile << int(*(x + i)) % 23;  //convert the characters into their ascii value%23 and write into the file
	}
	ofile.close(); //close the file

	cout << "For encryption scheme 2, see the results in file, encrypted_scheme2.txt " << endl;
}

//Qno.3 and 4

struct Node {

	int data;
	Node* next;
};

//Question no. 4
void sortedInsertNode(Node*& head, Node* newnode) {

	Node* curr = NULL;

	if (head == NULL || head->data >= newnode->data)
	{
		newnode->next = head;
		head = newnode;
	}
	else {
		curr = head;
		while (curr->next != NULL && curr->next->data < newnode->data)
		{
			curr = curr->next;

		}
		newnode->next = curr->next;
		curr->next = newnode;
	}
}



//Question no. 3
void swapNodes(Node* head, int x, int y) {

	if (x == y) { //same value no swapping required

		cout << "Element x is equal to elemet y" << endl;

	}
	else {
		//searching x and y while keeping track of their respective prev and curr pointers 
		Node* xprev = NULL, * xcurr = head;
		while (xcurr && xcurr->data != x) {
			xprev = xcurr;
			xcurr = xcurr->next;
		}

		Node* yprev = NULL, * ycurr = head;
		while (ycurr && ycurr->data != y) {
			yprev = ycurr;
			ycurr = ycurr->next;
		}

		//if either one of the elemet is missing
		if (xcurr == NULL) {
			cout << "Element "<<x<<" not found." << endl;
			return;
		}
		if (ycurr == NULL) {
			cout << "Element " << y << " not found." << endl;
			return;
		}

		if (xprev != NULL) { //if x is not the head

			xprev->next = ycurr;

		}
		else {
			head = ycurr;
		}

		if (yprev != NULL) {  //if y not the head

			yprev->next = xcurr;
		}
		else {
			head = xcurr;
		}

		//Swapping pointers 

		Node* temp = NULL;
	    temp	= ycurr->next;
		ycurr->next = xcurr->next;
		xcurr->next = temp;

	}
}
//Question no. 4
void deleteNode(Node*& head, int element) {

	Node* prev = NULL;
	Node* curr = head;

	while (curr && curr->data != element) {  //finding the element

		prev = curr;
		curr = curr->next;
	}
	if (curr) {  //if element exists
		if (prev)  //if not head
		{
			prev->next = curr->next; //change the prev to curr
			delete curr; //delete curr
		}
		else {
			head = curr->next;  //if head, make current head
			delete curr; //delete curr
		}
	}
	else {
		cout << "Element not in list." << endl; //if element does not exist in list
	}


}

void displayList(Node* head) {

	Node* current = head;   //prints the contents of list

	while (current != NULL) {
		cout << current->data << " ";
		current = current->next;
	}
	cout << endl;
}


int getWordCount(char* t) {

	int count = 0;
	while (*t++ != '\0') {

		if (isspace(*t))
			count++;
	}
	return count;
}

int main()
{


	//Question no. 1
	ifstream ifile;
	ifile.open("text.txt", ios_base::in | ios_base::binary); //open file

	ifile.seekg(0, ifile.end);   //get length of text
	int length = (int)ifile.tellg();
	ifile.seekg(0, ifile.beg);
	char *strg = new char[length];  //initialize text string with text length
	ifile.read(strg, length);  //read the files content into str
	ifile.close();
	strg[length] = '\0';  //adding null character to the string


	int wcount = getWordCount(strg); //getting word count in the string
	char** words=new char*[wcount];  //to initilaize this array

	char *ptr = strtok(strg, " ,.-\n\t"); //tokenizing the string to separate the words
	words[0]=ptr;
	
	
	for (int i = 1; ptr != NULL;i++) {

		ptr = strtok(NULL, " ,.-\n\t"); 
	
		words[i]=ptr;  //creating a list of words

	}
	
	for (int i = 0; i < wcount; i++) {


		for (int j = 0; j < strlen(words[i]); j++) {
			
			cout<<words[i][j];   //printing strings and their lengths 
		}
		cout<<" "<< strlen(words[i]) <<endl;
	}


	
	cout << "\n\nQuestion no. 2: Encrypt Decrypt using Scheme 1" << endl;
	cout << "text.txt contains the string to encrypt or decrypt, while the converted string is in file named, encrypted_scheme1.txt" << endl;
	encrypt_decrypt_scheme1(strg, length);  //Q2 part 1 and 2 (A)

	encryptionscheme2(strg, length); //Q2 part 1 b


	cout << "Question no. 4: " << endl;

	Node* list = NULL; //create a list
	Node* node1 = new Node();  //create new nodes
	Node* node2 = new Node();
	Node* node3 = new Node();
	Node* node4 = new Node();
	Node* node5 = new Node();

	cout << "Inserting element in List..." << endl;


	cout << "Inser 3 in list" << endl;
	node1->data = 3;    //enter data
	node1->next = NULL;
	sortedInsertNode(list, node1);  //Insert in list
	displayList(list);   //print the list contents

	cout << "Inser 1 in list" << endl;
	node2->data = 1;
	node2->next = NULL;
	sortedInsertNode(list, node2);
	displayList(list);

	cout << "Inser 5 in list" << endl;
	node3->data = 5;
	node3->next = NULL;
	sortedInsertNode(list, node3);
	displayList(list);

	cout << "Inser 4 in list" << endl;
	node4->data = 4;
	node4->next = NULL;
	sortedInsertNode(list, node4);
	displayList(list);


	cout << "Inser 2 in list" << endl;
	node5->data = 2;
	node5->next = NULL;
	sortedInsertNode(list, node5);
	displayList(list);

	cout<<endl;
	//Testing Question 3 function 
	cout << "Question 3: " << endl;
	cout << "Swapping Nodes" << endl;

	cout << "Swapping 2 and 3" << endl;
	swapNodes(list, 3, 2);
	displayList(list);

	cout << "Swapping 3 and 5" << endl;
	swapNodes(list, 3, 5);
	displayList(list);

	cout << "Swapping 6 and 2, when element 6 is not in list" << endl;
	swapNodes(list, 6, 2);
	displayList(list);

	cout << endl;
	//Testing Question 4 function by deleting elements from the list
	cout << "Question 4: " << endl;
	cout << "Deleting elements in list..." << endl;

	cout << "Delete elemet 1 from list" << endl;
	deleteNode(list, 1);
	displayList(list);

	cout << "Delete elemet 5 from list" << endl;
	deleteNode(list, 5);
	displayList(list);

	cout << "Delete elemet 3 from list" << endl;
	deleteNode(list, 3);
	displayList(list);

	cout << "Delete elemet 6 from list" << endl;
	deleteNode(list, 6);
	displayList(list);

	cout << "Delete elemet 4 from list" << endl;
	deleteNode(list, 4);
	displayList(list);

	cout << "Delete elemet 2 from list" << endl;
	deleteNode(list, 2);
	displayList(list);

	cout << "Delete elemet 2 from list again" << endl;
	deleteNode(list, 2);
	displayList(list);

}