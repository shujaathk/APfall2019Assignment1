
#include<iostream>
using namespace std;

/* defines the structure of a single linked list node*/
typedef struct list_node
{
   int data;
   struct list_node *next; // pointer to next node in the list 
}

node;

/* create new node */
node *getNewNode(int data) 
{
   node *new_node = new node;
   new_node->data = data;
   new_node->next = NULL;
   return new_node;
}

/* displays the list elements */
void displayList(node *head)
{
   cout << "Displaying List after Insertion : ";
   while (head != NULL) 
   {
      cout << head->data << " -> ";
      head = head->next;
   }
   cout << "NULL " << endl;
}

/* displays the list elements */
void displayList2(node *head) 
{
   cout << "Displaying List after Deletion : ";
   while (head != NULL) 
   {
      cout << head->data << " -> ";
      head = head->next;
   }
   cout << "NULL " << endl;
}


/* Search the node with element as data
   Return the pointer to the node if found else return NULL */
node *searchNode(node *head, int data)
{
   node *ptr = NULL;
   while (head)
   {
      if (head->data == data) {
         ptr = head;
         break;
      }
      head = head->next;
   }
   return ptr;
}

/* insert a node at the beginning of the list */
node *insertNodeBeg(node *head, int data) 
{
   node *ptr = getNewNode(data);
   if (head == NULL)
   { // if list is empty
      head = ptr;
   }
   else
   {
      ptr->next = head;
      head = ptr;
   }
   return head;
}

/* insert a node at the end of the list */
node *insertNodeEnd(node *head, int data) 
{
   node *ptr = getNewNode(data);
   if (head == NULL)
   { //if list is empty
      head = ptr;
   }
   else 
   {
      node *temp = head;
      while (temp->next != NULL) 
      { // move to the last node
         temp = temp->next;
      }
      temp->next = ptr; // insert node at the end
   }
   return head;
}

/* insert a node at the after a particular node in the list */
node *insertNodeAfter(node *head, int element, int data)
{
   // search the element after which node is to be inserted
   node *temp = searchNode(head, element);
   if (temp == NULL)
   { // element not found
      cout << "Element not found ... " << endl;
   }
   else 
   {
      node *ptr = getNewNode(data);
      if (temp->next == NULL) 
      { // node has to inserted after the last node
         temp->next = ptr;
      }
      else 
      {  // insert the node after the first or an intermediate node
         ptr->next = temp->next;
         temp->next = ptr;
      }
   }
   return head;
}

/* delete a particular node from the list */
node *deleteNode(node *head, int element) 
{
   node *temp = searchNode(head, element); // search the node to be deleted
   if (temp == NULL) 
   { // element not found
      cout << "Node to be deleted not found ... " << endl;
   }
   else 
   {
      if (temp == head)
      { // first node is to be deleted
         head = head->next;
         delete temp;
      }
      else 
      { // node to deleted is an intermediate or last node
         node *ptr = head;
         while (ptr->next != temp) 
         {
            ptr = ptr->next;
         }
         ptr->next = temp->next;
         delete temp;
      }
   }
   return head;
}

int main() 
{
   node *head = NULL;
   head = insertNodeBeg(head, 2);       // 2
   head = insertNodeBeg(head, 5);       // 5 -> 2
   head = insertNodeEnd(head, 9);      // 5 -> 2 -> 9
   displayList(head);
   head = deleteNode(head, 2);          // 5 -> 9 
   displayList2(head);
   return 0;
}